//
//  ViewController.swift
//  sf_Location
//
//  Created by agile on 04/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
     authorizationStatus()
    }
    
    func authorizationStatus() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways, .authorizedWhenInUse:
            setUpLocationManager()
        case .denied:
            print("Authorization is Set as Never")
            settingApp()
        case .restricted:
            print("Authorization is Restricted by Some Reason")
        default:
            break
        }
    }
    
    func settingApp() {
        <#function body#>
    }
    
    
    func setUpLocationManager() {
        locationManager = CLLocationManager()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        
    }
    
    @IBAction func btnStartUpdatingLocation(_ sender: Any) {
        locationManager.startUpdatingLocation()
        
    }
    
    @IBAction func btnStopUpdatingLocation(_ sender: Any) {
        locationManager.stopUpdatingLocation()
    }
    
}


extension ViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error : \(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("Updated Location : \(locations)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print("Authorization Status : \(status.userFrindlyName)")
    }
}

extension CLAuthorizationStatus{
    var userFrindlyName : String{
        switch self {
        case .notDetermined:
             return "notDetermined" ;
        case .restricted:
            return "restricted" ;
        case .denied:
            return "denied" ;
        case .authorizedAlways:
            return "authorizedAlways" ;
        case .authorizedWhenInUse:
            return "authorizedWhenInUse" ;
        
        }
    }
}

//
//  ThirdViewController.swift
//  sf4DelegateProtocolWithPushViewController
//
//  Created by agile on 25/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet var txtNameThirdVC: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnPushToForthVC(_ sender: Any) {
        
        let fourthVC = self.storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        
        navigationController?.pushViewController(fourthVC, animated: true)
        
        
    }
    
}

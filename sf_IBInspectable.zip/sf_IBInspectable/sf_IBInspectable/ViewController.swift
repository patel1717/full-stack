//
//  ViewController.swift
//  sf_IBInspectable
//
//  Created by agile on 19/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
class LabelCustomAttributes: UILabel {
    
    @IBInspectable var mycolor1 : UIColor = UIColor.yellow
    @IBInspectable
    public var cornerRadius: CGFloat = 2.0 {
        didSet {
            self.layer.cornerRadius = self.cornerRadius
            self.clipsToBounds = true
        }
    }
    
    
    override func awakeFromNib() {
        super .awakeFromNib()
        self.backgroundColor = mycolor1
    }
}


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}


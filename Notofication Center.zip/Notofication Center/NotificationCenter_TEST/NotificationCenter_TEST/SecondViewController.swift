//
//  SecondViewController.swift
//  NotificationCenter_TEST
//
//  Created by agile-2 on 14/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.notificationHandler(notification:)),
                                               name: NSNotification.Name(rawValue: NSNotification.Name.eventXYZ),
                                               object: nil)
        
    }
    
    
    @objc func notificationHandler(notification:Notification) {
        
        if let userInfo = notification.userInfo {
            print("Event handled in SECOND VC WITH DATA : \(userInfo)")
        }else{
            print("Event handled in SECOND VC")
        }
        
        
        
        
    }
    
}

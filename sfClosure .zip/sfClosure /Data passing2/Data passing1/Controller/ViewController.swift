//
//  ViewController.swift
//  Data passing1
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtnumberFVC: UITextField!
    @IBOutlet var txtName: UITextField!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }

   

    @IBAction func btnSubmit(_ sender: UIButton) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.pushViewController(secondVC, animated: true)
        
    }
    
}


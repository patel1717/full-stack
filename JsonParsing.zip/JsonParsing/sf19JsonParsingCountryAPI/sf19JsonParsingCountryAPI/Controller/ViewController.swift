//
//  ViewController.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//MARK:- PROPERTIES
    
    @IBOutlet weak var btnCall: UIButton!
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    btnCall.backgroundColor = StringConstant_File.shared.appButtonColor1
        
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnCall(_ sender: Any) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        guard let navigationController = self.navigationController else {
            return
        }
        
        ServiceManager.shared.fetchDataFromAPI(urlstr: "https://restcountries.eu/rest/v2/all") { (isSuccess, message, countryData) in
            print("API Call Result \(isSuccess) , API Call message \(message) & Number Of Countries \(countryData)")
            DispatchQueue.main.async {
                 secondVC.tableViewCountry.reloadData()
            }
        }
        
        navigationController.pushViewController(secondVC, animated: true)
    }
    
}


//
//  ServiceManager.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {

    static let shared : ServiceManager = ServiceManager()
    typealias closureComplition = ((Bool,String,[AICountries]) -> Void)
    
    
    func fetchDataFromAPI(urlstr : String , complition : @escaping closureComplition) {
        guard let url = URL(string: urlstr) else {
            complition(false, "url Not Get", [])
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, responce, error) in
            if let err = error{
                complition(false, "Error : \(err.localizedDescription)", [])
                return
            }
            
            if let data = data {
                do {
                    let array = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    if let jsonArray  = array as? NSArray{
                        for eachDict in jsonArray{
                            if let finalDict = eachDict as? [String:Any]{
                                let model = AICountries(name: finalDict["name"] as! String)
                                    appDelegate.arrGloble.append(model)
                            }else{
                                complition(false, "Something Went Wrong", [])
                                return
                            }
                        }
                    }else{
                        complition(false, "Something Went Wrong Data Into Json", [])
                        return
                    }
                    
                    
                }catch{
                    complition(false, "SomeThing Went Wrong", [])
                    return
                }
                complition(true, "Got API responce Successfully", appDelegate.arrGloble)
            }
        }
        dataTask.resume()
        
    }
    
}

//
//  ViewController.swift
//  sf8TableView
//
//  Created by agile on 06/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tableVewTest: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDIdLoad1")
        doSetUpUI()
        
    }

    private func doSetUpUI(){
        
        tableVewTest.dataSource = self
        tableVewTest.delegate = self
        
        tableVewTest.register(UINib(nibName:"TableViewCellCustom",bundle:nil), forCellReuseIdentifier: "Cell")
        
        
    }

    

}


//MARK:- EXTENSION UITableViewDataSource
extension ViewController : UITableViewDataSource{
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableVewTest.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        
        cell.lblNameCellCustom.text = "Section \(indexPath.section), Row \(indexPath.row)"
        
        return cell
        
    }
    
    
    
}





//MARK:- EXTENSION UITableViewDelegate
extension ViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

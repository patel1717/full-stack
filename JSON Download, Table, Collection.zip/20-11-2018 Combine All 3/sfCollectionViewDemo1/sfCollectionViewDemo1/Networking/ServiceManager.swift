//
//  ServiceManager.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {

    //MARK:- PROPERTIES
    static let shared : ServiceManager = ServiceManager()
    typealias closureComplition = (Bool,String,[AICountry]) -> Void
    
    let image2  = UIImage()
    typealias closureImageComplition = ((Bool,String,UIImage) -> Void)
    
    //MARK:- FUNCTIONS COUNTRIE API
    func fetchDataFromAPI(urlstr:String, complition : @escaping closureComplition) {
        guard let url = URL(string: urlstr) else {
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            
            if let err = error {
                complition(false,"there is some error\(err.localizedDescription)",[])
            }
            
            if let data = data{
                
                do{
                    
                    let arrJson = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    if let allArray = arrJson as? NSArray{
                        for finalArray in allArray{
                            if let allDict = finalArray as? [String:Any]{
                                let model = AICountry(name: allDict["name"] as! String, capital: allDict["capital"] as! String , region: allDict["region"] as! String)
                                        appDelegate.globalArray.append(model)
                                complition(true,"API Call Successfull",appDelegate.globalArray)
                            }
                            
                            else{
                                complition(false,"some error over there in parsing a Dictionary",[])
                            }
                        }
                    }else{
                        complition(false,"some error over there in parsing a Array",[])
                    }
                    
                }catch{
                complition(false,"some error in data",[])
                }
                
                
            }else{
                complition(false,"some error in data",[])
            }
            
        }
        dataTask.resume()
    }
    
    
    //MARK:- FUNCTIONS IMAGE API
    func fetchDataFromImageAPI(urlstr : String , complition : @escaping closureImageComplition) {
        guard let url = URL(string: urlstr) else {
            complition(false, "url Not Get", image2)
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, responce, error) in
            if let err = error{
                complition(false, "Error : \(err)", self.image2)
                return
            }
            
            if let imageData = data {
                
                let jsonImage  = UIImage(data: imageData)
                
                complition(true, "Got API responce Successfully", jsonImage!)
                
            }else{
                complition(false, "Not Get",self.image2)
                return
            }
        }
        dataTask.resume()
        
    }
    
    


}

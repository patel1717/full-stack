//
//  PointTableViewCell.swift
//  ResFind Project
//
//  Created by NeelPurohit on 02/03/18.
//  Copyright © 2018 NeelPurohit. All rights reserved.
//

import UIKit

class PointTableViewCell: UITableViewCell {

    
    @IBOutlet weak var pointimages: UIImageView!
    
    @IBOutlet weak var pointnames: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  ViewController.swift
//  sfUser_Defaults
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

struct allKeys {
    static let keyName  = "keyName"
    static let keySwitch  = "keySwitch"
}

class ViewController: UIViewController {

    @IBOutlet weak var txtField1: UITextField!
    
    @IBOutlet weak var switch1: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
   
        doSetUpUI()
    }

    func doSetUpUI() {
        if let setValue = UserDefaults.standard.object(forKey: allKeys.keyName){
            txtField1.text = setValue as? String
        }
        
        if let setvalue2 = UserDefaults.standard.object(forKey: allKeys.keySwitch){
            switch1.isOn = setvalue2 as! Bool
        }
        
    }
    
    @IBAction func btnSave(_ sender: Any) {
        
        UserDefaults.standard.set(txtField1.text, forKey: allKeys.keyName)
        UserDefaults.standard.set(switch1.isOn, forKey: allKeys.keySwitch)
        UserDefaults.standard.synchronize()
        
    }
    
   
    
    
}


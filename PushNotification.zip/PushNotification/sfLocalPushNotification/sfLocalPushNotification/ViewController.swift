//
//  ViewController.swift
//  sfLocalPushNotification
//
//  Created by agile on 08/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    
    @IBAction func requestNotification(_ sender: Any) {

    askPermision()
        
    }
    
    
    func askPermision() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) { (granted, error) in
            
            if granted {
                print("Permision Granted")
                self.setUpUserNotification()
            }else{
                print("\n\n Error : \(String(describing: error?.localizedDescription))")
            }
        }
    }
    
    func setUpUserNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Title"
        content.body = "This is Body"
        
        content.sound = UNNotificationSound.default()
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        
        let request = UNNotificationRequest(identifier: "identifier_One", content: content, trigger: trigger)
        
        
        UNUserNotificationCenter.current().add(request) { (error) in
            
            if error != nil {
                print("Request not added successfully")
            }else{
                print("Request added successfully")
            }
        }
        
        UNUserNotificationCenter.current().delegate = self
    }
    
}

extension ViewController  : UNUserNotificationCenterDelegate{
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        print("Will Present Called... \(notification)")
        
        if notification.request.identifier == "identifier_One" {
            completionHandler([.alert, .sound , .badge])
        }else{
            completionHandler([])
        }
        
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("did receive responce of notification \(response.notification)")
    }
    
}


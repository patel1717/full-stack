//
//  TableViewCellCustom.swift
//  sfCollectionViewDemo1
//
//  Created by SagarMac on 20/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class TableViewCellCustom: UITableViewCell {

    @IBOutlet weak var lblTableViewCellCustom: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

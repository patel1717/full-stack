//
//  ThirdViewController.swift
//  sf5TextFieldDelegate
//
//  Created by agile on 28/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
    @IBAction func btnSendToForthVC(_ sender: Any) {
        
        let ForthVC = self.storyboard?.instantiateViewController(withIdentifier: "ForthViewController") as!ForthViewController
        guard let navigationController = self.navigationController else {
            return
        }
        navigationController.pushViewController(ForthVC, animated: true)
        
    }
    
}

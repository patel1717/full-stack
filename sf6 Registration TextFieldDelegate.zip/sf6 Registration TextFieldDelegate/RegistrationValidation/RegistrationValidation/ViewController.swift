//
//  ViewController.swift
//  RegistrationValidation
//
//  Created by SagarMac on 09/09/18.
//  Copyright © 2018 SagarMac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,protocolDelegateDataEdit {
    func saveWasPerformed(editedText: String) {
        self.txtUserNameFirstVC.text = editedText
//        self.txtContactNumberFirstVC.text = editedText
//        self.txtEmailFirstVC.text = editedText
//        self.txtPassWordFirstVC.text = editedText
//        self.txtRepeatPassWordFirstVC.text = editedText
    }
    

    
    @IBOutlet weak var txtUserNameFirstVC: UITextField!
    @IBOutlet weak var txtContactNumberFirstVC: UITextField!
    @IBOutlet weak var txtEmailFirstVC: UITextField!
    @IBOutlet weak var txtPassWordFirstVC: UITextField!
    @IBOutlet weak var txtRepeatPassWordFirstVC: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController

        guard let navigationController = self.navigationController else {
            return
        }

        navigationController.pushViewController(secondVC, animated: true)
        
        secondVC.username = self.txtUserNameFirstVC.text!
        secondVC.contactnumber = self.txtContactNumberFirstVC.text!
        secondVC.email = self.txtEmailFirstVC.text!
        secondVC.password = self.txtPassWordFirstVC.text!
        secondVC.repeatpassword = self.txtRepeatPassWordFirstVC.text!
        
        secondVC.delegate = self
    }
    

}


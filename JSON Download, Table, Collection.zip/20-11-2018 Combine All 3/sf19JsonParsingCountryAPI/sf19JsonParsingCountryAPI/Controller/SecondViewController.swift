//
//  SecondViewController.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
//MARK:- PROPERTIES
    static let shared : SecondViewController = SecondViewController()
    
    @IBOutlet weak var tableViewCountry: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.tableViewCountry.reloadData()
        tableViewCountry.delegate = self
        tableViewCountry.dataSource = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableViewCountry.register(nibName, forCellReuseIdentifier: "Cell")
    }
}

//MARK:- EXTENSION UITableViewDataSource
extension SecondViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.globalArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewCountry.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.lblTableViewCellCustom.text = appDelegate.globalArray[indexPath.row].name
        return cell
    }
}

//MARK:- EXTENSION UITableViewDelegate
extension SecondViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 62
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        guard let navigationController = self.navigationController else {
            return
        }
        
        thirdVC.modelToReceiveData.capital = appDelegate.globalArray[indexPath.row].capital
        thirdVC.modelToReceiveData.region = appDelegate.globalArray[indexPath.row].region
        
        navigationController.pushViewController(thirdVC, animated: true)
    }
}

//
//  ServiceManager.swift
//  JsonForHttp
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {
    //MARK:- PROPERTIES
    static let shared : ServiceManager = ServiceManager()
typealias closureComplition = (Bool, String, [AIMmo]) -> Void
    
//    var userName :String = ""
//    var passWord :String = ""
  
    var userName = appDelegate.globalArrayTest[0].UserName
    var passWord = appDelegate.globalArrayTest[0].Password
    
    //MARK:- FUNCTION FOR FETCH DATA POST
    func fetchDataFromAPIPOST(urlstr : String , complition : @escaping closureComplition) {
        guard let url1 = URL(string: urlstr)  else {
            return
        }

        var request = URLRequest(url:url1)
        
        request.httpMethod = "POST"
        
        let postString = "UserName=\(userName)&Password=\(passWord)";
        print(postString)
//        let postString = "UserName=Sagar&Password=sagar";

        request.httpBody = postString.data(using: String.Encoding.utf8);

        let dataTask = URLSession.shared.dataTask(with: request) { (data, responce, error) in
            if let err = error{
                print("Error In First Step Task: \(err.localizedDescription)")
                complition(false, "There Was Some Error", [])
                return
            }
            
            if let data1 = data {
                do{
                    let dictData = try JSONSerialization.jsonObject(with: data1, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    if let parseJSON = dictData as? [String:Any]{
                        let userValue = parseJSON["User"]
                        if let userInnerValue = userValue as? [String:Any] {
                          
                              let userUserId = userInnerValue["UserId"]
                            let userUserName = userInnerValue["UserName"]
                            let userPassword = userInnerValue["Password"]
                            let userContactNumber = userInnerValue["ContactNo"]
                            let userEmail = userInnerValue["Email"]
                            let userCountry = userInnerValue["Country"]
                            let userTotalCoin = userInnerValue["TotalCoin"]
                            print("final112 \(userUserId) , \(userUserName) , \(userPassword) , \(userContactNumber) , \(userEmail) , \(userCountry) , \(userTotalCoin)")
                            
                        
                            
                            let model1 = AIMmo(UserId: userUserId as? Int, UserName: userUserName as? String, Password: userPassword as? String, ContactNo: userContactNumber as? Int, Email: userEmail as? String, Country: userCountry as? String, TotalCoin: userTotalCoin as? Int)
                            
                            print(appDelegate.globalArray)
                            appDelegate.globalArray.append(model1)
                            print(appDelegate.globalArray)
                            print("Contact number :\(String(describing: userUserName))")
                        }
                        print("User Value : \(String(describing: userValue))")
                        print("Login SuccessFull")
                        print("json : \(parseJSON)")
                       
            
                        
                    }
                    
                    
                    
//                    if let dictAllData = dictData as? [String:Any]{
//                        print("json data : \(dictAllData)")
//                        let model = AIMmo(UserId: dictAllData["UserId"] as! Int, UserName: dictAllData["UserName"] as! String, Password: dictAllData["Password"] as! String, ContactNo: dictAllData["ContactNo"] as! String, Email: dictAllData["Email"] as! String, DOB: dictAllData["DOB"] as! Date, Country: dictAllData["Country"] as! String, TotalCoin: dictAllData["TotalCoin"] as! Int, IsActive: dictAllData["IsActive"] as! Bool, Status: dictAllData["Status"] as! String)
//                        appDelegate.globalArray.append(model)
//                        complition(true, "API Call Done Successfully", appDelegate.globalArray)
//                    }
                    
                }catch{
                    print("There is Some Error")
                    complition(false, "There Was Some Error", [])
                }
                
            }else{
                complition(false, "There Was Some Error", [])
            }
        }
        dataTask.resume()
        
    }

    
    
    
    
    
    //MARK:- FUNCTION FOR INSERT DATA POST
    func insertDataToAPIPOST(urlstr : String , complition : @escaping closureComplition) {
        guard let url1 = URL(string: urlstr)  else {
            return
        }
        
        var request = URLRequest(url:url1)
        
        request.httpMethod = "POST"
        
//        let postString = "UserName=\(userName)&Password=\(passWord)";
         let postString = "UserName=\(userName)&Password=\(passWord)";
//    {"UserId": 1,
//        "UserName":"Sanjay",
//        "Password":"sanjay",
//        "ContactNo": "123123",
//        "Email":"skakaniya@gmail.com",
//        "DOB": "0001-01-01T00:00:00",
//        "Country": "India",
//        "TotalCoin": 0,
//        "IsActive": true,
//        "Status": "Active"}
        print(postString)
        //        let postString = "UserName=Sagar&Password=sagar";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let dataTask = URLSession.shared.dataTask(with: request) { (data, responce, error) in
            if let err = error{
                print("Error In First Step Task: \(err.localizedDescription)")
                complition(false, "There Was Some Error", [])
                return
            }
            
            if let data1 = data {
                do{
                    let dictData = try JSONSerialization.jsonObject(with: data1, options: JSONSerialization.ReadingOptions.mutableContainers)
                    
                    if let parseJSON = dictData as? [String:Any]{
                        let userValue = parseJSON["User"]
                        if let userInnerValue = userValue as? [String:Any] {
                            let userAllInnerValue = userInnerValue["ContactNo"]
                            print("Contact number :\(String(describing: userAllInnerValue))")
                        }
                        print("User Value : \(String(describing: userValue))")
                        print("Login SuccessFull")
                        print("json : \(parseJSON)")
                        
                    }
                    
                    
                    
                    //                    if let dictAllData = dictData as? [String:Any]{
                    //                        print("json data : \(dictAllData)")
                    //                        let model = AIMmo(UserId: dictAllData["UserId"] as! Int, UserName: dictAllData["UserName"] as! String, Password: dictAllData["Password"] as! String, ContactNo: dictAllData["ContactNo"] as! String, Email: dictAllData["Email"] as! String, DOB: dictAllData["DOB"] as! Date, Country: dictAllData["Country"] as! String, TotalCoin: dictAllData["TotalCoin"] as! Int, IsActive: dictAllData["IsActive"] as! Bool, Status: dictAllData["Status"] as! String)
                    //                        appDelegate.globalArray.append(model)
                    //                        complition(true, "API Call Done Successfully", appDelegate.globalArray)
                    //                    }
                    
                }catch{
                    print("There is Some Error")
                    complition(false, "There Was Some Error", [])
                }
                
            }else{
                complition(false, "There Was Some Error", [])
            }
        }
        dataTask.resume()
        
    }

    
    
    
    
    
    
    
    
    
    
    
    //MARK:- FUNCTION FOR FETCH DATA GET
//    func fetchDataFromAPIGet(urlstr : String , complition : @escaping closureComplition) {
//        guard let url = URL(string: urlstr)  else {
//            return
//        }
//
//        let dataTask = URLSession.shared.dataTask(with: url) { (data, responce, error) in
//            if let err = error{
//                print("Error In First Step Task: \(err.localizedDescription)")
//                complition(false, "There Was Some Error", [])
//                return
//            }
//
//            if let data1 = data {
//                do{
//                let dictData = try JSONSerialization.jsonObject(with: data1, options: JSONSerialization.ReadingOptions.mutableContainers)
//
//                    if let dictAllData = dictData as? [String:Any]{
//                        let model = AIMmo(UserId: dictAllData["UserId"] as! Int, UserName: dictAllData["UserName"] as! String, Password: dictAllData["Password"] as! String, ContactNo: dictAllData["ContactNo"] as! Int, Email: dictAllData["Email"] as! String, Country: dictAllData["Country"] as! String, TotalCoin: dictAllData["TotalCoin"] as! Int)
//                        appDelegate.globalArray.append(model)
//                        complition(true, "API Call Done Successfully", appDelegate.globalArray)
//                    }
//
//                }catch{
//                    print("There is Some Error")
//                complition(false, "There Was Some Error", [])
//                }
//
//            }else{
//                complition(false, "There Was Some Error", [])
//            }
//        }
//        dataTask.resume()
//
//    }
    
}



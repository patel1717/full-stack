//
//  ViewController.swift
//  JsonHttpTest
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
   
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //MARK:- BUTTON ACTIONS
    @IBAction func btnLogin(_ sender: Any) {
        
        fetchDataFromApiPost()
    }
    

    func fetchDataFromApiPost() {
        let myUrl = URL(string: "http://mmoreward.com/User/UserLogin");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        
        
        let postString = "UserName=\(String(describing: txtUserName.text!))&Password=\(String(describing: txtPassword.text!))";
        
//                let postString = "UserName=Sagar&Password=sagar";
        print(postString)
        
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                return
            }
            
            
            print("response = \(String(describing: response))")
            
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                
                if let parseJSON = json as? [String:Any]{
                     let userValue = parseJSON["User"]
                    if let userInnerValue = userValue as? [String:Any] {
                        let userAllInnerValue = userInnerValue["ContactNo"]
                        print("Contact number :\(String(describing: userAllInnerValue))")
                    }
                    print("User Value : \(String(describing: userValue))")
                    print("Login SuccessFull")
                    print("json : \(parseJSON)")
                    
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }

    
    
    
}


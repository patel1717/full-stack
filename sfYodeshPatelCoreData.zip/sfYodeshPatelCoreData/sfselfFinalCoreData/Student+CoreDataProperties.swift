//
//  Student+CoreDataProperties.swift
//  sfselfFinalCoreData
//
//  Created by agile on 05/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var name: String?
    @NSManaged public var address: String?
    @NSManaged public var city: String?
    @NSManaged public var mobile: String?

}

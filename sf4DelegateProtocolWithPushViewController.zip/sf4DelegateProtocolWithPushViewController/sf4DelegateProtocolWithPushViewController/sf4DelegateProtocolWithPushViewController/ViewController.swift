//
//  ViewController.swift
//  sf4DelegateProtocolWithPushViewController
//
//  Created by agile on 25/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ViewController: UIViewController,SecondVCDelegate {
    func saveWasPerformed(editedText: String) {
        self.txtNameFirstVC.text = editedText
    }
    

    @IBOutlet var txtNameFirstVC: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        
           let SecondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as!SecondViewController

        
            guard let navigationController = self.navigationController else {
                return
            }
        
            navigationController.pushViewController(SecondVC, animated: true)
        
        
        
        
        SecondVC.name = txtNameFirstVC.text!
        
        
        

        SecondVC.delegate = self
        
        
        
        
        
        
        
    }
    

}


//
//  ServiceManager.swift
//  sf16JsonParsingAndSaveCoreData
//
//  Created by agile on 16/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
import CoreData

class ServiceManager: NSObject {

    static let shared = ServiceManager()
    let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func fetchData(url: String, complition : (_ isSucess:Bool, _ message:String, _ data:[AIPost]) -> Void) {
        
       let post1 = AIPost(userId: "1", id: "1", title: "Title1", body: "body1")
        let post2 = AIPost(userId: "2", id: "2", title: "Title2", body: "body2")
        let post3 = AIPost(userId: "3", id: "3", title: "Title3", body: "body3")
        let post4 = AIPost(userId: "4", id: "4", title: "Title4", body: "body4")

        let allPost = [post1,post2,post3,post4]

        let apiCallStetus = true
        
        if apiCallStetus {
        complition(true,"API Call Successfull",allPost)
        }else{
            print("API Call Not Done")
        }
        
    }
    
    
    func save(Object:[AIPost]) {
        let save1 = NSEntityDescription.insertNewObject(forEntityName: "Student", into: contex!) as! Student
        //FIX ME
        save1.userId = Object["userId"]
        save1.id = Object["userId"]
        save1.title = Object["userId"]
        save1.body = Object["userId"]
        
        do{
            try contex?.save()
        }catch{
            print("Data Could Not Save In Student Table")
        }
    }
    
}

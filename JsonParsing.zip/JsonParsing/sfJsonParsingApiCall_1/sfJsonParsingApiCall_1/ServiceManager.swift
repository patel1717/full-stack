//
//  ServiceManager.swift
//  sfJsonParsingApiCall_1
//
//  Created by agile on 11/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
    
class ServiceManager: NSObject {

    static let shared : ServiceManager = ServiceManager()
    

    func fetchData(url : String, complition : (_ isSuccess:Bool, _ message:String, _ data:[AIPost]) -> Void) {
//        let post1 = AIPost(UserId: 1, Id: 1, Title: "Title1", Body: "Body1")
//        let post2 = AIPost(UserId: 2, Id: 2, Title: "Title2", Body: "Body2")
//        let post3 = AIPost(UserId: 3, Id: 3, Title: "Title3", Body: "Body3")
//        let post4 = AIPost(UserId: 4, Id: 4, Title: "Title4", Body: "Body4")
//        let post5 = AIPost(UserId: 5, Id: 5, Title: "Title5", Body: "Body5")
//
//        let allPost = [post1,post2,post3,post4,post5]
        
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if let data = data{
                print(data)
                
                do{
//                    let json = try JSONSerialization.jsonObject(with: data, options: [])
//                    print(json)
                    
                    appDelegate.modelArrayVar = try JSONSerialization.jsonObject(with: data, options: []) as! [AIPost]
                    print(appDelegate.modelArrayVar)
                    
                    
                    //                appDelegate.modelArrayVar = try JSONDecoder().decode([AIPost].self, from: data!)
                    //
                    //                for allArray in appDelegate.modelArrayVar{
                    //
                    //                    print(allArray.name)
                    //                }
                    
                }catch{
                    print("error")
                }
                
            }
            
    
        }.resume()
        
        let apiCallSuccessFully = true
        
        if apiCallSuccessFully{
            complition(true, "API call Successfull", appDelegate.modelArrayVar)
            
            
            for allArray in appDelegate.modelArrayVar{
                
                print(allArray.name)
            }
            
//            if let arrayAllPost = modelArrayVar as? NSArray{
////                for allArray in arrayAllPost {
////                    if let dict = allArray as? NSDictionary{
////                        if let dict2 = dict["name"]{
////                            print(dict2)
////                        }
////                    }
////                }
//                print(arrayAllPost)
//
//
//            }
        }else{
            complition(false, "API Call Not Done", [])
        }
    }
    
}

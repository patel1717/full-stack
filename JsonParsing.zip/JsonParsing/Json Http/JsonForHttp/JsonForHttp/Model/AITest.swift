//
//  AITest.swift
//  JsonForHttp
//
//  Created by agile on 26/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

struct AITest {
    var UserName : String
    var Password : String
    
//    init() {
//
//    }
    
    init(user : AITest) {
        self.UserName = user.UserName
        self.Password = user.Password
    }
    
    init(UserName: String, Password: String){
        self.UserName = UserName
        self.Password = Password
    }
}

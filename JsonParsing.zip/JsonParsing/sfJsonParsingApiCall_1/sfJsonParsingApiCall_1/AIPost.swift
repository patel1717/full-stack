//
//  AIPost.swift
//  sfJsonParsingApiCall_1
//
//  Created by agile on 11/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

//class AIPost: NSObject {
//var UserId : Int = 0
//var Id : Int = 0
//var Title : String = ""
//var Body : String = ""
//}

//struct AIPost {
//    var UserId : Int = 0
//    var Id : Int = 0
//    var Title : String = ""
//    var Body : String = ""
//}


struct AIPost : Decodable{
    var name = String()
    var capital = String()
    var region = String()
}

//
//  AICountries.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

//class AICountries: NSObject {
//
//}


struct AICountries {
//    var name:String
    var image:UIImage
}

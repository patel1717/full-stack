//
//  SecondViewController.swift
//  JsonForHttp
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit


class SecondViewController: UIViewController {
    
    //MARK:- PROPERTIES
    @IBOutlet weak var tableView1: UITableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpTableView()
    }
    
    func doSetUpTableView() {
        tableView1.dataSource = self
        tableView1.delegate = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableView1.register(nibName, forCellReuseIdentifier: "Cell")
    }
    
}

//MARK:- EXTENSION UITableViewDataSource
extension SecondViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        print(appDelegate.globalArray.count)
        return appDelegate.globalArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView1.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.lblTableViewCellCustom.text = appDelegate.globalArray[indexPath.row].UserName
//        print(cell)
        return cell
    }
}

//MARK:- EXTENSION UITableViewDelegate
extension SecondViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 62
    }
    
    //    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //        <#code#>
    //    }
}






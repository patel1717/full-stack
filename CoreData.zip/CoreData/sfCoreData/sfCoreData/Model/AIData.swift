//
//  AIData.swift
//  sfCoreData
//
//  Created by agile on 29/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
//
//class AIData: NSObject {
//
//}

struct AIData {
    var name : String
    var idPerson : String
    var date : Date
}

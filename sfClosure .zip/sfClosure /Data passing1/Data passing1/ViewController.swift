//
//  ViewController.swift
//  Data passing1
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtnumberFVC: UITextField!
    @IBOutlet var txtName: UITextField!

    var closureDemo1 : ((_ name:String , _ number:String) -> Void)?

    
    static var shared : ViewController = ViewController()
    
    var name1 : String?
    var number1 : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        txtName.text = name1
        txtnumberFVC.text = number1
    }

   

    @IBAction func btnSubmit(_ sender: UIButton) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        
        guard let navigationController = self.navigationController else {
            return
        }
        
       
        
//        closureDemo1?(txtName.text! ,txtnumberFVC.text!)
        
        secondVC.closureDemo2 = { (name, number) in
            print("Closure Called")
            print(name,number)
            self.name1 = name
            self.number1 = number
        }

        navigationController.pushViewController(secondVC, animated: true)
        
    }
    
}


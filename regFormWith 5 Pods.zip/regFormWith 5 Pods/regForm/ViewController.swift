//
//  ViewController.swift
//  regForm
//
//  Created by agile on 01/01/01.
//  Copyright © 2001 agile.New. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet var TxtFirstname: UITextField!
    
    @IBOutlet var TxtLastname: UITextField!
    
    @IBOutlet var TxtEmail: UITextField!
    
    @IBOutlet var TxtContact: UITextField!
    
    @IBOutlet var TxtAddress: UITextField!
    
    @IBOutlet var TxtCity: UITextField!
    
    
    @IBOutlet var TxtState: UITextField!
    
    
    @IBOutlet var TxtZIpCode: UITextField!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func BtnReset(_ sender: UIButton) {
    }
    
    @IBAction func BtnSubmit(_ sender: UIButton) {
        
        let showdata:ShowdataVC = self.storyboard?.instantiateViewController(withIdentifier: "ShowdataVC") as! ShowdataVC
    
        showdata.strFirstname = TxtFirstname.text
        showdata.strLastname = TxtLastname.text
        showdata.stremail = TxtEmail.text
        showdata.strcontact = TxtContact.text
        showdata.straddress = TxtAddress.text
        showdata.strcity = TxtCity.text
        showdata.strstate = TxtState.text
        showdata.strzipcode = TxtZIpCode.text
        
        self.navigationController?.pushViewController(showdata,animated: true)
        
    
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


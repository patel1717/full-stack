//
//  ServiceManager.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {

    static let shared : ServiceManager = ServiceManager()
    typealias closureComplition = ((Bool,String,[AICountries]) -> Void)
    
    
    func fetchDataFromAPI(urlstr : String , complition : @escaping closureComplition) {
        guard let url = URL(string: urlstr) else {
            complition(false, "url Not Get", [])
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, responce, error) in
            if let err = error{
                complition(false, "Error : \(err.localizedDescription)", [])
                return
            }
            
            if let imageData = data {
 
                let jsonImage  = UIImage(data: imageData)
     
                let model = AICountries(image: jsonImage!)
                appDelegate.arrGloble.append(model)
  
                
                complition(true, "Got API responce Successfully", appDelegate.arrGloble)
            }else{
                complition(false, "Not Get", [])
                return
            }
        }
        dataTask.resume()
        
    }
    
}

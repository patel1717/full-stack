//
//  AIMmo.swift
//  JsonForHttp
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

//class AIMmo: NSObject {
//
//}

struct AIMmo {
    var UserId : Int
    var UserName : String
    var Password : String
    var ContactNo : String
    var Email : String
    var DOB : Date
    var Country : String
    var TotalCoin : Int
    var IsActive : Bool
    var Status : String
}




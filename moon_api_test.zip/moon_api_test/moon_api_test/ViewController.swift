//
//  ViewController.swift
//  moon_api_test
//
//  Created by agile on 1/1/01.
//  Copyright © 2001 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
     @IBOutlet weak var table_view: UITableView!
    
     var myDict = NSMutableDictionary()
     var name = NSMutableArray()
     var phone = NSMutableArray()
     var rate = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()
        table_view.register(UINib(nibName:"TableViewCell",bundle: nil), forCellReuseIdentifier: "cell")
        
        
       table_view.rowHeight = UITableViewAutomaticDimension
        table_view.estimatedRowHeight = 300.0
                GetDataCall()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    
    return 120.0
    
    
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myDict.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : TableViewCell = table_view.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        cell.name.text = name[indexPath.row] as? String
        cell.phone.text = phone[indexPath.row] as? String
        cell.rate.text = String(describing: rate[indexPath.row])
        
      
        
        return cell
        
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 130.0
//    }
//    
    

        func GetDataCall ()
        {
            let url = URL(string: "http://www.moontechnolabs.com/betaapps/Twilio_test/priceList.php")
            let Task = URLSession.shared.dataTask(with: url!)
            {(data , responce , error) in
                if error != nil
                {
                    print("Error")
                }
                else{
                    if let content = data
                    {
                        do{
                            let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                          //  print(myJson)
                            
                          
                    self.myDict = myJson as! NSMutableDictionary
                   print(self.myDict)
                            
                            for i in 1...self.myDict.count{
                                
                                let data = self.myDict.value(forKey: "\(i)") as! NSMutableDictionary
                            
                                print(data)
                                
                                
                        let name = data.value(forKey: "Name") as! String
                                
                        let PhoneNo = data.value(forKey: "PhoneNo") as! String
                                
                        let Rate = data.value(forKey: "Rate") as! NSNumber
                                
                        print(String(describing: Rate)as NSString)


                                
                       // print(name)
                        self.name.add(name)
                        self.phone.add(PhoneNo)
                        self.rate.add(Rate)
                        
                                
                                
                }
                            
                  //  print(self.rate)
                                     }
                            
                                       catch{
                        }
                        
                    }
                    
                }
                
                
                
                  self.table_view.reloadData()
                
            }
            Task.resume()
        }
}

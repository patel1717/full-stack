//
//  ViewController.swift
//  JsonDownloadTaskExtra
//
//  Created by agile on 20/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
@IBOutlet weak var btnDownloadPDF: UIButton!
    
    let filePath = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask).first!
    
    func localFilePath(url : URL) -> URL {
        let path1 = filePath.appendingPathComponent(url.lastPathComponent)
        return path1
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func btnDownloadPDF(_ sender: Any) {
        let url = URL(string: "https://www.hq.nasa.gov/alsj/a17/A17_FlightPlan.pdf")!
        let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")
        let downloadSession = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        let task : URLSessionDownloadTask = downloadSession.downloadTask(with: url)
        task.resume()
    }
    
}

extension ViewController : URLSessionDownloadDelegate{
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let sourceUrl = downloadTask.originalRequest?.url  else{return}
        let destinationUrl = localFilePath(url: sourceUrl)
        print(destinationUrl)

        let fileManager = FileManager.default
        
        try? fileManager.removeItem(at: destinationUrl)
        do{
            try fileManager.copyItem(at: location, to: destinationUrl)
        }catch let error{
            print("There Some Error : \(error.localizedDescription)")
        }
        
    }
    
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
    
        let progress = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
    
        let totalSize = ByteCountFormatter.string(fromByteCount: totalBytesExpectedToWrite,
                                                  countStyle: .file)
        
        print("Progress : \(progress), Total Size : \(totalSize)")
    }
    
}


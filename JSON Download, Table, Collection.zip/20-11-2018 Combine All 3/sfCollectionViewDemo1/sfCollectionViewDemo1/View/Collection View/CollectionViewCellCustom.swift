//
//  CollectionViewCellCustom.swift
//  sfCollectionViewDemo1
//
//  Created by agile on 19/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class CollectionViewCellCustom: UICollectionViewCell {

    static let shared : CollectionViewCellCustom = CollectionViewCellCustom()
    @IBOutlet weak var uiView12: UIView!
    @IBOutlet weak var lblCollectionViewCellCustom: UILabel!
   
    override func awakeFromNib() {
      
        super.awakeFromNib()
        // Initialization code
    }

}

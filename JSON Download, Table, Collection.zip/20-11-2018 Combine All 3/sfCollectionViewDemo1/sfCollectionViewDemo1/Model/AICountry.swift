//
//  AICountry.swift
//  sfCollectionViewDemo1
//
//  Created by agile on 20/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

//class AICountry: NSObject {
//
//}

struct AICountry {
    var name : String
    var capital : String
    var region : String
    
//    init() {
//        self.name = ""
//        self.capital = ""
//        self.region = ""
//    }
}

//
//  ThirdViewController.swift
//  sfNotificationCenter
//
//  Created by agile on 14/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

extension NSNotification.Name {
    static let name = "xyz"
}

class ThirdViewController: UIViewController {

    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtNumber: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func btnNotificationCenterPost(_ sender: Any) {
       
       ServiceManager.shared.notificationCenterPost(name: txtName.text!, number: txtNumber.text!)
    }
}

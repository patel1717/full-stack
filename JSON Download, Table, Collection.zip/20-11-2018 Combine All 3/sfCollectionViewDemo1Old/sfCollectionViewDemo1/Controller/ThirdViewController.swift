//
//  ThirdViewController.swift
//  sfCollectionViewDemo1
//
//  Created by SagarMac on 20/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    //MARK:- PROPERTIES OF TABLE VIEW
    @IBOutlet weak var tableView1: UITableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
     doSetUpTableView()
    }
    
    func doSetUpTableView()  {
        tableView1.dataSource = self
        tableView1.delegate = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableView1.register(nibName, forCellReuseIdentifier: "Cell")
    }
}

//MARK:- EXTENSION UITableViewDataSource
extension ThirdViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.globalArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView1.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCellCustom
        cell.lblTableViewCellCustom.text = appDelegate.globalArray[indexPath.row].capital
        return cell
    }
    
    
}

//MARK:- EXTENSION UITableViewDelegate
extension ThirdViewController : UITableViewDelegate{

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 62
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let fifthVC = self.storyboard?.instantiateViewController(withIdentifier: "FifthViewController") as! FifthViewController
        
        guard let navigationController = navigationController else {
            return
        }
        
        fifthVC.model1 = appDelegate.globalArray[indexPath.row]
        
        navigationController.pushViewController(fifthVC, animated: true)
    }
}

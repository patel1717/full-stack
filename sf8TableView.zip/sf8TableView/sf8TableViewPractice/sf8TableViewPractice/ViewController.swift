//
//  ViewController.swift
//  sf8TableViewPractice
//
//  Created by agile on 07/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var TableViewArch: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpUI()
    }

  
    private func doSetUpUI(){
        TableViewArch.dataSource = self
        TableViewArch.delegate = self
        
        TableViewArch.register(UINib(nibName:"TableViewCellCustom",bundle:nil), forCellReuseIdentifier: "Cell")
    }

}



//MARK:- EXTENSION UITableViewDataSource
extension ViewController : UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewArch.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom

        cell.lblNameCellCustom.text = "Section \(indexPath.section) , Row \(indexPath.row)"
        return cell
    }
    
    
}




//MARK:- EXTENSION UITableViewDelegate
extension ViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

//
//  ViewController.swift
//  Location_TEST
//
//  Created by agile-2 on 03/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    var locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setupLocationManager()
        isLocationPermissionGranted()
    }
    
    func isLocationPermissionGranted() {
        
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways, .authorizedWhenInUse :
            setupLocationManager()
        case .denied:
            print("Location permission denied")
            showDeniedAlert()
        case .notDetermined:
            print("Location permission not determined yet")
        case .restricted:
            print("Restricted")
        }
        
    }
    
    func showDeniedAlert() {
    
        guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
            return
        }
        
        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                // Checking for setting is opened or not
                print("Setting is opened: \(success)")
            })
        }

        
    }
    
    func setupLocationManager() {
        
        locationManager = CLLocationManager()

        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
    }
    
    
    @IBAction func btnStartUpdatingLocationPressed(_ sender: Any) {
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func btnStopUpdatingLocationPressed(_ sender: Any) {
        locationManager.stopUpdatingLocation()
    }
    
}

extension ViewController : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("\nDid Update Locations : \(locations)")
//        manager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("\nDid fail with error : \(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print("\nDid change authorization : \(status.userFriendlyName)")
    }
}

extension CLAuthorizationStatus {
    
    var userFriendlyName:String {
        
        switch self {
        case .notDetermined:        return "notDetermined";
        case .restricted:           return "restricted";
        case .denied:               return "denied";
        case .authorizedAlways:     return "authorizedAlways";
        case .authorizedWhenInUse:  return "authorizedWhenInUse";
        }
    }
}



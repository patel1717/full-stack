//
//  Student+CoreDataClass.swift
//  sfselfFinalCoreData
//
//  Created by agile on 05/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

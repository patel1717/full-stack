//
//  AIPost.swift
//  sf16JsonParsingAndSaveCoreData
//
//  Created by agile on 16/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

//class AIPost: NSObject {
//
//
//}

struct AIPost {
    var userId : String = ""
    var id : String = ""
    var title : String = ""
    var body : String = ""
}

//
//  SearchViewController.swift
//  sf17JsonRaywanderitch
//
//  Created by agile on 18/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    @IBOutlet weak var tableViewForSongList: UITableView!
    @IBOutlet weak var searchBarForSongList: UISearchBar!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewForSongList.delegate = self
        tableViewForSongList.dataSource = self
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        
        tableViewForSongList.register(nibName, forCellReuseIdentifier: "Cell")
    }
}

extension SearchViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewForSongList.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.lblTitleCellCustom.text = "\(indexPath.section) & Row Name \(indexPath.row)"
        return cell
    }
    
    
}

extension SearchViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 62.5
    }
    
}

//
//  PointofInterestViewController.swift
//  ResFind Project
//
//  Created by DarshanHirpara on 02/03/18.
//  Copyright © 2018 DarshanHirpara. All rights reserved.
//

import UIKit

class PointofInterestViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
   
    
    
    @IBOutlet var btnMenuButton: UIBarButtonItem!
    
    var PointName = ["Bar", "Nightclub", "lounge", "Athletics", "Arts&Entertainment", "Parking", "Bank", "Car Wash", "Clothing Store", "Liquor Store", "Supermarket" , "Hair Salon", "Hotel" , "Convenience Store" , "Gas Station"]
    var PointImg = [#imageLiteral(resourceName: "bar"),#imageLiteral(resourceName: "nightclub"),#imageLiteral(resourceName: "lounge"),#imageLiteral(resourceName: "gym"),#imageLiteral(resourceName: "arts_and_entertainment"),#imageLiteral(resourceName: "parking"),#imageLiteral(resourceName: "bank"),#imageLiteral(resourceName: "car_wash"),#imageLiteral(resourceName: "clothing"),#imageLiteral(resourceName: "liquor_store"),#imageLiteral(resourceName: "supermarket"),#imageLiteral(resourceName: "hair_salon"),#imageLiteral(resourceName: "hotel"),#imageLiteral(resourceName: "convenience_store"),#imageLiteral(resourceName: "gas_station")]
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Point Of Interest"
        
        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        
        
        do {
            var urlString = "https://api.foursquare.com/v2/venues/explore?ll=40.7,-74&client_id=K31Q3R2FPS4LPGDGKYFX53JQDL00VHOI0JK1AFKPBOKPGATD&client_secret=OS5XV33DJSXRFAJ03DYYSVNEBZGSJE0HCKLAL3YG5NN05LUN&v=20180803&query=4bf58dd8d48988d1ca941735"
            var request = URLRequest(url: URL(string: urlString)!, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 60.0)
            
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config)
            
            let task = session.dataTask(with: request, completionHandler: {(data, response, error) in
                
                if error != nil {
                    
                    print(error!.localizedDescription)
                    
                }
                    
                else {
                    if let data = data {
                        var dict = try! JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                        print("dict :: \(dict)")
                    }
                }
            })
            
            task.resume()
        }
            
        catch {
            // handle the error
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PointName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let pocell = tableView.dequeueReusableCell(withIdentifier: "pointcell") as! PointTableViewCell
        pocell.pointimages?.image = PointImg[indexPath.row]
        pocell.pointnames?.text = PointName[indexPath.row]
        return pocell
        
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //Set initial cell
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 100, 0)
        cell.layer.transform = transform
        
        //final Set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

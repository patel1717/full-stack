//
//  SecondViewController.swift
//  sfNotificationCenter
//
//  Created by agile on 14/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(notification:)), name: NSNotification.Name(rawValue: NSNotification.Name.name), object: nil)
    }
    
    @objc func notificationHandler(notification:Notification) {
     print("Notification Observe2")
        if let userInfo =  notification.userInfo {
            print("Data is \(userInfo)")
        }else{
            print("Data Not Found")
        }
    }
}

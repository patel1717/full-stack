//
//  SecondViewController.swift
//  sfExtraPractice
//
//  Created by agile on 04/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    
    @IBOutlet var txtNameSecondVC: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.txtNameSecondVC.text = FinalName
        
        // Do any additional setup after loading the view.
    }

    var FinalName:String = ""
   
    @IBAction func btnBackToFirstVC(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
        
    }
    
}

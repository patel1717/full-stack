//
//  ViewController.swift
//  sf_MapView
//
//  Created by agile on 05/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    
    @IBOutlet weak var mapView1: MKMapView!
    var regionRadius : CLLocationDistance = 1000
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      mapView1.delegate = self
    }
    
   
    func makeCenterOnLocation(location:CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
        mapView1.setRegion(coordinateRegion, animated: true)
        
    }
    
    
    
    @IBAction func setLocation(_ sender: Any) {
     makeCenterOnLocation(location: CLLocation(latitude: 22.4072, longitude: 73.1822))
        
    }
    
    @IBAction func pinLocation(_ sender: Any) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 22.4072, longitude: 73.1822)
        annotation.title = "Pune"
        mapView1.addAnnotation(annotation)
    }
    
}

extension ViewController : MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let identifire = "marker"
        var view : MKMarkerAnnotationView
        
        if let dequedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifire) as? MKMarkerAnnotationView {
            dequedView.annotation = annotation
            view = dequedView
        }else {
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifire)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: -5)
            
            let temporary1 = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            temporary1.backgroundColor = UIColor.blue
            
            view.rightCalloutAccessoryView = temporary1
        }
        
    return view
    }
    
    
}


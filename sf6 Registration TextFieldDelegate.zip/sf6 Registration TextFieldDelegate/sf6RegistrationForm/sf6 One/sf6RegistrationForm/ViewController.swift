//
//  ViewController.swift
//  sf6RegistrationForm
//
//  Created by agile on 29/08/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

protocol protocolTextFieldLengthChecker{
    func textFieldLengthCheck() -> Bool
    func textFieldLengthCheck2() -> Bool
    func textFieldLengthCheck3() -> Bool
    func textFieldLengthCheck4() -> Bool
}

class ViewController: UIViewController {
    
 
    

    
    
    // MARK :- PROPERTIES
    @IBOutlet var txtUserNameFirstVC: UITextField!
    
    
    @IBOutlet var txtContactNoFirstVC: UITextField!
    
    
    @IBOutlet var txtEmailFirstVC: UITextField!
    
    
    @IBOutlet var txtPasswordFirstVC: UITextField!
    
    
    
    
    
    
    // MARK :- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
      
        print("viewDidLoad1")
        
        doSetupUI()
        
        
    }

    private func doSetupUI(){
        
        self.txtUserNameFirstVC.delegate = self
 
        self.txtUserNameFirstVC.autocorrectionType = .no
        
        
        self.txtContactNoFirstVC.delegate = self
        self.txtContactNoFirstVC.keyboardType = .phonePad
        self.txtContactNoFirstVC.autocorrectionType = .no
    
        
        self.txtEmailFirstVC.delegate = self
        self.txtEmailFirstVC.keyboardType = .emailAddress
     
    self.txtEmailFirstVC.autocorrectionType = .no
        
        
        self.txtPasswordFirstVC.delegate = self
        self.txtPasswordFirstVC.autocorrectionType = .no
           self.txtPasswordFirstVC.returnKeyType = UIReturnKeyType.done
    
        
    }
    
    
    
    
    
    @IBAction func btnSubmitRegistrationData(_ sender: Any) {
       
        if textFieldLengthCheck(), textFieldLengthCheck2(), textFieldLengthCheck3(), textFieldLengthCheck4(){
            let seconVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
            
            guard let navigationController = self.navigationController else {
                return
            }
            
            navigationController.pushViewController(seconVC, animated: true)
            
            seconVC.userName = txtUserNameFirstVC.text!
            seconVC.contactNo = txtContactNoFirstVC.text!
            seconVC.emailAddress = txtEmailFirstVC.text!
            seconVC.passWord = txtPasswordFirstVC.text!
        }else {
            print("Please Enter Minimum 3 Character")
        }
        
      
        
    }
    
    
    

}


















 //MARK :- VALIDATION

extension ViewController : protocolTextFieldLengthChecker{
   
    func textFieldLengthCheck() -> Bool {
        if let count1 = txtUserNameFirstVC.text?.count{
            let isValid = count1 >= 3
            return isValid
        }else{
            return false
        }
    }
    
    
    func textFieldLengthCheck2() -> Bool {
        if let count2 = txtContactNoFirstVC.text?.count{
            let isValid = count2 >= 3
            return isValid
        }else{
            return false
        }
    }
    
    func textFieldLengthCheck3() -> Bool {
        
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: txtEmailFirstVC.text!)
        
//        if let count3 = txtEmailFirstVC.text?.count{
//            let isValid = count3 >= 3
//            return isValid
//        }else{
//            return false
//        }
    }
    
    
    func textFieldLengthCheck4() -> Bool {
        if let count4 = txtPasswordFirstVC.text?.count{
            let isValid = count4 >= 3
            return isValid
        }else{
            return false
        }
    }
    
    
    
}



extension ViewController : UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("SHOULD BEGIN")
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("DID BEGIN")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        print("SHOULD END EDITING")
        return true
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        print("DID END EDITING WITH REASON")
    }
    

    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("SHOULD RETURN")
        textField.resignFirstResponder()
        return true
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        print("SHOULD CLEAR")
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        print("TEXT FIELD RANGE = \(range) & STRING = \(string)")

        return true
       
    }

}


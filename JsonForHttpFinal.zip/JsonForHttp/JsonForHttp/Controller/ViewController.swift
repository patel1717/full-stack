//
//  ViewController.swift
//  JsonForHttp
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController : UIViewController {
    
    //MARK:- PROPERTIES
//    let parameters = ["name": "username", "password": "password123"]
//    Alamofire.request("http://MyServer.com/api/login", method: .post, parameters: parameters, encoding: URLEncoding.httpBody)
    
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func btnCallApi(_ sender: Any) {
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        guard let navigationController = navigationController else {
            return
        }


        ServiceManager.shared.fetchDataFromAPIPOST(urlstr: "http://asiaticelevators.com/User/UserLogin") { (message, isSuccess, data) in
            print("Success : \(isSuccess) ,Success Message: \(message) ,Data : \(data)")
            DispatchQueue.main.async {
                secondVC.tableView1.reloadData()
            }
        }
        
        navigationController.pushViewController(secondVC, animated: true)
    }
    
}

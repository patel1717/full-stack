//
//  SeconVCViewController.swift
//  sf4practice
//
//  Created by agile on 27/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

protocol SecondVCDelegate {
    func saveWasPerformed(editedText : String)
    
}


class SeconVCViewController: UIViewController {

    @IBOutlet var txtNmaeSecondVC: UITextField!
    
    
    var name : String = ""
    var delegate :SecondVCDelegate?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    self.txtNmaeSecondVC.text = name
    }

   
    @IBAction func btnSendToFirstVC(_ sender: Any) {
        
    if let delegate = self.delegate , let text = txtNmaeSecondVC.text
    {
        delegate.saveWasPerformed(editedText: text)
        }
        
        
        navigationController?.popViewController(animated: true)
        
    }
    
   
    
    
    
    
    
    @IBAction func btnPushAndSendToThirdVC(_ sender: Any) {
        
        let ThirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdVCViewController") as!ThirdVCViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.pushViewController(ThirdVC, animated: true)
        
        
        ThirdVC.ThirdName = txtNmaeSecondVC.text!
        
        
    }
    
}

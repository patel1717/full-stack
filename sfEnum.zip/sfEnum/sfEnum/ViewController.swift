//
//  ViewController.swift
//  sfEnum
//
//  Created by agile on 12/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

enum PlanType : Int{
    case prepaid,postpaid,unlimited
}

enum Rating : Int{
    case bad, good, best
}


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       doSetUpEnum()
    }

    func doSetUpEnum() {
        print("Plan Type : \(PlanType.prepaid.rawValue)")
        print("Plan Type : \(PlanType.postpaid.rawValue)")
        print("Plan Type : \(PlanType.unlimited.rawValue)")
        
        
        printRating(type: Rating.bad.rawValue)
        printRating(type: Rating.good.rawValue)
        printRating(type: Rating.best.rawValue)
    }
    
    func printRating(type:Int)  {
        if type == 0 {
            print("bad")
        }
        if type == 1 {
            print("good")
        }
        if type == 2 {
            print("best")
        }
    }
    
    
    

}


//
//  ThirdVCViewController.swift
//  sf4practice
//
//  Created by agile on 27/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ThirdVCViewController: UIViewController {

    @IBOutlet var txtNameThirdVC: UILabel!
    var ThirdName : String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      self.txtNameThirdVC.text = ThirdName
    }

 
    
    @IBAction func btnPushToForthVC(_ sender: Any) {
        
        let ForthVC = self.storyboard?.instantiateViewController(withIdentifier: "ForthVCViewController") as! ForthVCViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        
        navigationController.pushViewController(ForthVC, animated: true)
        
    }
    
   
    
    

}

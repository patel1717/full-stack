//
//  ViewController.swift
//  sfselfFinalCoreData
//
//  Created by agile on 05/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtNameFirstVC: UITextField!
    @IBOutlet var txtAddressFirstVC: UITextField!
    @IBOutlet var txtCityFirstVC: UITextField!
    @IBOutlet var txtMobileFirstVC: UITextField!
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }


    @IBAction func btnSave(_ sender: Any) {
        
        let dict = ["name":txtNameFirstVC.text, "address":txtAddressFirstVC.text, "city":txtCityFirstVC.text, "mobile":txtMobileFirstVC.text]
        dataBaseHelper.shareInstance.save(object: dict as! [String : String])
       
    }
    
}


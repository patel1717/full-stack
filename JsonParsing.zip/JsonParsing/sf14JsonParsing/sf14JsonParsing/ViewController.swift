//
//  ViewController.swift
//  sf14JsonParsing
//
//  Created by agile on 11/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    
        if let path = Bundle.main.path(forResource: "JsonTestFile_1", ofType: "json"){
            
            let finalUrl = URL(fileURLWithPath: path)
            do{
                
            let jsonData = try Data(contentsOf: finalUrl, options: Data.ReadingOptions.mappedIfSafe)
                
                let jsonResult = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.allowFragments)
//                        print(jsonResult)
                
                if let arr = jsonResult as? NSArray{
                    
                    for alldict in arr {
                        if let dict = alldict as? NSDictionary{

                            if let keyName = dict["First1"]{
                                
                                if let innerArray1 = keyName as? NSArray{
                                    
                                    for innerDict1 in innerArray1{
                                        if let innerDictFinal = innerDict1 as? NSDictionary{
                                            if let innerKeyName1 = innerDictFinal["innerFirstKey2"]{
                                                if let innerArray2 = innerKeyName1 as? NSArray{
                                                    for i in 0..<innerArray2.count{
                                                        if let innerDict4 = innerArray2[i] as? NSDictionary{
                                                            switch i {
                                                            case 1 :
                                                                if let innerFinalName5 = innerDict4["innerFinal2Key"]{
                                                                    print(innerFinalName5)
                                                                }
                                                            default : break
                                                            }
                                                        }
                                                    }
                                                    print(innerArray2[0])
                                                }
//                                                print(innerKeyName1)
                                            }
//                                            print(innerDictFinal)
                                        }
                                    }
                                    
                                    
//                                    for i in 0..<innerArray1.count{
//                                        switch i {
//                                        case 0 :
//
//
//
//                                        }
//
//                                    }
                                }
                                
//                                print(keyName)
                            }
                        }
                        
                    }
                }
                
            }catch{
                print(error.localizedDescription)
            }
        }
    }
}


//
//  ViewController.swift
//  ContactDemo1
//
//  Created by agile on 22/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- PROPERTIES
    
    @IBOutlet var txtNameFirstVC: UITextField!
    @IBOutlet var txtNumberFirstVC: UITextField!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    
    //MARK:- BUTTON ACTION
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        let SecondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
    navigationController.pushViewController(SecondVC, animated: true)
        SecondVC.arrRows = [txtNameFirstVC.text!]

      
       
        
    }
    
    


}


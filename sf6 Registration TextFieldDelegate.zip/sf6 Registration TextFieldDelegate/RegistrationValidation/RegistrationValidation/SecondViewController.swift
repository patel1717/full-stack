//
//  SecondViewController.swift
//  RegistrationValidation
//
//  Created by SagarMac on 09/09/18.
//  Copyright © 2018 SagarMac. All rights reserved.
//

import UIKit

protocol protocolDelegateDataEdit {
    func saveWasPerformed(editedText:String)
//     func saveWasPerformed(editedText:[String])
}

class SecondViewController: UIViewController {

    
    //MARK:- PROPERTIES
    @IBOutlet weak var txtUserNameSecondVC: UITextField!
    @IBOutlet weak var txtContactNumberSecondVC: UITextField!
    @IBOutlet weak var txtEmailSecondVC: UITextField!
    @IBOutlet weak var txtPassWordSecondVC: UITextField!
    @IBOutlet weak var txtRepeatPassWordSecondVC: UITextField!
    
    var username : String = ""
    var contactnumber : String = ""
    var email : String = ""
    var password : String = ""
    var repeatpassword : String = ""
    
    var delegate : protocolDelegateDataEdit?
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()

        self.txtUserNameSecondVC.text = username
        self.txtContactNumberSecondVC.text = contactnumber
        self.txtEmailSecondVC.text = email
        self.txtPassWordSecondVC.text = password
        self.txtRepeatPassWordSecondVC.text = repeatpassword
      

        
        
        
        
    }

    //MARK:- BUTTON EVENT
    @IBAction func btnSendToFirstVC(_ sender: Any) {
        
        
        if let delegate = self.delegate , let text = txtUserNameSecondVC.text{
            delegate.saveWasPerformed(editedText: text)
        }
        
//        if let delegate = self.delegate , let text = txtUserNameSecondVC.text, let text2 = txtContactNumberSecondVC.text,let text3 = txtEmailSecondVC.text,let text4 = txtPassWordSecondVC.text,let text5 = txtRepeatPassWordSecondVC.text {
//            delegate.saveWasPerformed(editedText: [text,text2,text3,text4,text5])
//        }
        
    }
    
}

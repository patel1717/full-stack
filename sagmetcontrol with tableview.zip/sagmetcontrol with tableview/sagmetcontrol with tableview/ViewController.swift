//
//  ViewController.swift
//  sagmetcontrol with tableview
//
//  Created by agilemac-74 on 19/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var segOut: UISegmentedControl!
    @IBOutlet var tableVIew: UITableView!
    var ahData:[AhmedabadModel] = []
    var muData:[MumbaiModel] = []
    var baData:[BangloreModel] = []
    var puData:[PuneModel] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ahData = [
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a1"),title:"Navratri"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a2"),title:"Rann Utsav"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a3"),title:"Shamlaji Melo"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a4"),title:"Uttarayan"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a5"),title:"Bhavnath Melo"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a6"),title:"Rath Yatra"),
            AhmedabadModel(city:"City :- Ahmedabad", image: #imageLiteral(resourceName: "a7"),title:"Janmastami")
        ]
       
        muData = [
            MumbaiModel(city:"City :- Mumbai", image: #imageLiteral(resourceName: "a1"),title:"Navratri"),
            MumbaiModel(city:"City :- Mumbai", image: #imageLiteral(resourceName: "a2"),title:"Rann Utsav"),
            MumbaiModel(city:"City :- Mumbai", image: #imageLiteral(resourceName: "a3"),title:"Shamlaji Melo"),
            MumbaiModel(city:"City :- Mumbai", image: #imageLiteral(resourceName: "a4"),title:"Uttarayan"),
            MumbaiModel(city:"City :- Mumbai", image: #imageLiteral(resourceName: "a5"),title:"Bhavnath Melo")
            
        ]
       baData = [
        BangloreModel(city:"City :- Banglor", image: #imageLiteral(resourceName: "a6"),title:"Navratri"),
        BangloreModel(city:"City :- Banglor", image: #imageLiteral(resourceName: "a7"),title:"Rann Utsav"),
        BangloreModel(city:"City :- Banglor", image: #imageLiteral(resourceName: "a1"),title:"Shamlaji Melo"),
        BangloreModel(city:"City :- Banglor", image: #imageLiteral(resourceName: "a2"),title:"Uttarayan"),
        BangloreModel(city:"City :- Banglor", image: #imageLiteral(resourceName: "a3"),title:"Bhavnath Melo")
        
        
        ]
        
      puData = [
        PuneModel(city:"City :- Pune", image: #imageLiteral(resourceName: "a5"),title:"Navratri"),
        PuneModel(city:"City :- Pune", image: #imageLiteral(resourceName: "a6"),title:"Rann Utsav"),
        PuneModel(city:"City :- Pune", image: #imageLiteral(resourceName: "a7"),title:"Shamlaji Melo"),
        PuneModel(city:"City :- Pune", image: #imageLiteral(resourceName: "a1"),title:"Uttarayan"),
        PuneModel(city:"City :- Pune", image: #imageLiteral(resourceName: "a2"),title:"Bhavnath Melo")
        
        ]
    }

    
    @IBAction func btnSegClick(_ sender: Any) {
        self.tableVIew.reloadData()
    }
    
}


extension ViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var value = 0
        
        switch segOut.selectedSegmentIndex {
        case 0:
            value = ahData.count
            break
        case 1:
            value = muData.count
            break
        case 2:
            value = baData.count
            break
        case 3:
            value = puData.count
            break
            
        default:
            break
        }
        return value
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableVIew.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath)as! TableViewCell
        
        switch segOut.selectedSegmentIndex {
        case 0:
            cell.lblTitle.text = ahData[indexPath.row].title
            cell.lblCity.text = ahData[indexPath.row].city
            cell.img.image = ahData[indexPath.row].image
            break
        case 1:
            cell.lblTitle.text = muData[indexPath.row].title
            cell.lblCity.text = muData[indexPath.row].city
            cell.img.image = muData[indexPath.row].image
            break
        case 2:
            cell.lblTitle.text = baData[indexPath.row].title
            cell.lblCity.text = baData[indexPath.row].city
            cell.img.image = baData[indexPath.row].image
            break
        case 3:
            cell.lblTitle.text = puData[indexPath.row].title
            cell.lblCity.text = puData[indexPath.row].city
            cell.img.image = puData[indexPath.row].image
            break
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let festivalVC = self.storyboard?.instantiateViewController(withIdentifier: "FestivatViewController") as! FestivatViewController
        festivalVC.ahData = ahData[indexPath.row]
        self.navigationController?.pushViewController(festivalVC, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    
}

//
//  ViewController.swift
//  contact-PlayerDemo
//
//  Created by agile on 25/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import ContactsUI
import AVKit

class ViewController: UIViewController {
    
    @IBOutlet weak var viewAnimation: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnAnimation(_ sender: Any) {
        
        UIView.animate(withDuration: 0.5,
                       delay: 0.1,
                       options: UIViewAnimationOptions.curveEaseIn,
                       animations: { () -> Void in
                        var fabricTopFrame = self.viewAnimation.frame
                        fabricTopFrame.origin.y -= fabricTopFrame.size.height

                        self.viewAnimation.frame = fabricTopFrame
        }, completion: { (finished) -> Void in
            // ....
        })
        
        
        
        
        
    }
    @IBAction func btnContact(_ sender: Any) {
        let cnPicker = CNContactPickerViewController()
        cnPicker.delegate = self
        self.present(cnPicker, animated: true, completion: nil)
    }
    @IBAction func player(_ sender: Any) {
        
        guard let bundleFileUrl = Bundle.main.url(forResource: "AutoLayout_09-08-2018", withExtension: "mov") else { return }
        
        var  playerItem = AVPlayerItem(url: bundleFileUrl)
        
        // let player = AVPlayer(url: URL(fileURLWithPath: localFilePath))
        let player = AVPlayer.init(playerItem: playerItem)
        
        let playerController = AVPlayerViewController()
        playerController.player = player
        self.present(playerController, animated: true) {
            player.play()
        }
    }
    
}


extension ViewController: CNContactPickerDelegate{
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contacts: [CNContact]) {
        contacts.forEach { contact in
            for number in contact.phoneNumbers {
                let phoneNumber = number.value
                print("number is = \(phoneNumber)")
            }
        }
    }
    func contactPickerDidCancel(_ picker: CNContactPickerViewController) {
        print("Cancel Contact Picker")
    }
}

//
//  ViewController.swift
//  sfIcon
//
//  Created by agile on 13/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func btnCustomFonts(_ sender: UIButton) {
        sender.titleLabel?.font = UIFont(name: "MartineScript", size: 45)
    }
    

}


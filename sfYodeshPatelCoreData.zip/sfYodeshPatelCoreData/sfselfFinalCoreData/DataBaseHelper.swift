//
//  DataBaseHelper.swift
//  sfselfFinalCoreData
//
//  Created by agile on 05/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class dataBaseHelper{
    static var shareInstance = dataBaseHelper()
    
    let contex = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:String]){
        let insertEntity = NSEntityDescription.insertNewObject(forEntityName: "Student", into: contex!) as! Student
        insertEntity.name = object["name"]
        insertEntity.address = object["address"]
        insertEntity.city = object["city"]
        insertEntity.mobile = object["mobile"]
        
        do{
         try contex?.save()
        }
        catch{
            print("Data Not Save")
        }
    }
}

//
//  ViewController.swift
//  PickerView1
//
//  Created by agile on 17/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

struct country : Decodable {
    let name : String
}

class ViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet var lblNamePickerView: UILabel!
    @IBOutlet var txtFieldForPickerView: UITextField!
    @IBOutlet var pickerViewTest: UIPickerView!
    
    var countries = [country]()

   
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        pickerViewTest.isHidden = true
//        txtFieldForPickerView.inputView = pickerViewTest
        
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error == nil {
                do{
                self.countries = try JSONDecoder().decode([country].self, from: data!)
                }catch{
                    print("Error")
                }
                
                DispatchQueue.main.async {
                    self.pickerViewTest.reloadComponent(0)
                }
                print(self.countries.count)
            }
        }.resume()
        
        
        pickerViewTest.dataSource = self
        pickerViewTest.delegate = self
        
    }

}



//MARK:- EXTENSION UIPickerViewDataSource
extension ViewController : UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countries.count
    }
    
    
}

//MARK:- EXTENSION UIPickerViewDelegate
extension ViewController : UIPickerViewDelegate{
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("Row \(row)  Component \(component)")
        
        lblNamePickerView.text = countries[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row].name
    }
//    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
//
//        let pickerUiView = UIView(frame : CGRect(x:0, y:0, width:100, height:150))
//        pickerUiView.backgroundColor = UIColor.red
//
//        return pickerUiView
//    }

}

//MARK:- EXTENSION

extension ViewController : UITextFieldDelegate{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if pickerViewTest.isHidden == true {
               pickerViewTest.isHidden = false
        }
     
        return true
    }
}



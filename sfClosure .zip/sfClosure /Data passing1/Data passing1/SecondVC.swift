//
//  SecondVC.swift
//  Data passing1
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    @IBOutlet var txtnumber: UITextField!
    @IBOutlet var txtSecond: UITextField!
    
    var name2 : String?
    var number2 : String?
    
    
    var closureDemo2 : ((_ name:String , _ number:String) -> Void)?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
  
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        
        closureDemo2!(txtSecond.text!, txtnumber.text!)
        
    }
    }




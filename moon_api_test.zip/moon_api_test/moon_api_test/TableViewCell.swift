//
//  TableViewCell.swift
//  moon_api_test
//
//  Created by agile on 10/31/17.
//  Copyright © 2017 agile. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var name_ns: NSLayoutConstraint!
    
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var phone: UILabel!
    
    
    
    @IBOutlet weak var rate: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
    
        
        
        
//        
//        if self.name_ns.constant >= 42{
//            
//            self.name_ns.constant = phone.frame.width + 42
//            self.layoutIfNeeded()
//            self.setNeedsUpdateConstraints()
//            
//        }
       // phone.sizeToFit()
       // name.sizeToFit()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

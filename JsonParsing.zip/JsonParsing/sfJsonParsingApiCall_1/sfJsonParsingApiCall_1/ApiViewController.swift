//
//  ApiViewController.swift
//  sfJsonParsingApiCall_1
//
//  Created by agile on 11/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ApiViewController: UIViewController {

    //MARK:- PROPERTIES
    let url = "https://jsonplaceholder.typicode.com/posts"
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnApiCall(_ sender: Any) {
        
        ServiceManager.shared.fetchData(url: url) { (isSuccess, message, posts) in
            if isSuccess{
                print("\n \(isSuccess) \n \(message) \n \(posts.count)")
            }else{
                print("Api Failed")
            }
        }
        
    }
}

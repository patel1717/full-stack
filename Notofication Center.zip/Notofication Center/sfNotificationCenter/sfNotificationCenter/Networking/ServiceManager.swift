//
//  ServiceManager.swift
//  sfNotificationCenter
//
//  Created by agile on 14/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {

    static let shared : ServiceManager = ServiceManager()
    
    func notificationCenterPost(name:String, number:String) {
         NotificationCenter.default.post(name: NSNotification.Name(rawValue: NSNotification.Name.name), object: self, userInfo: [name:number])
    }
    
}

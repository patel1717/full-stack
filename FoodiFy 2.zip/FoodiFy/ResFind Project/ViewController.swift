//
//  ViewController.swift
//  ResFind Project
//
//  Created by DarshanHirpara on 14/02/18.
//  Copyright © 2018 NeelPurohit. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    
    var foodName = ["All Cusines", "American/Burgers", "Asian", "Breakfast", "Coffee", "Itlian", "Japanese/Sushi", "Pizza", "Seafood", "Steakhouse", "Sandwiches", "More"]
    var foodImg = [#imageLiteral(resourceName: "All Cuisines"), #imageLiteral(resourceName: "Burger"), #imageLiteral(resourceName: "Asian") ,#imageLiteral(resourceName: "BreakFast"), #imageLiteral(resourceName: "Coffee"),#imageLiteral(resourceName: "Itlian"), #imageLiteral(resourceName: "Japanese Sushi"),#imageLiteral(resourceName: "Pizza"), #imageLiteral(resourceName: "SeaFood"),#imageLiteral(resourceName: "Steakhouse"), #imageLiteral(resourceName: "Sandwich2"),#imageLiteral(resourceName: "More") ]
    
    
    @IBOutlet var btnMenuButton2: UIBarButtonItem!
    //Mark : MenuButton Outlet
   // @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    
    @IBOutlet var btnMenuButton: UIBarButtonItem!
    var currentColorArrayIndex = -1
    var colorArray:[(color1:UIColor , color2:UIColor)] = []
    
    override func viewDidLoad() {
//        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        
        btnMenuButton2.target = revealViewController()
        btnMenuButton2.action = #selector(SWRevealViewController.revealToggle(_:))
    //btnMenuButton!.target = revealViewController()
//btnMenuButton!.action = #selector(SWRevealViewController.revealToggle(_:))
        
        self.title = "FoodiFy"
        
    }
    
    
    
   //let backgroundImage = UIImage(named: "Menu background")
    //let imageView = UIImageView(image: #imageLiteral(resourceName: "MenuBackground"))
    //self.tableView.backgroundView = imageView
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return foodName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.imgFoodImage?.image = foodImg[indexPath.row]
        cell.lblFoodName?.text = foodName[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //Set initial cell
        cell.alpha = 0
         let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 100, 0)
         cell.layer.transform = transform
        
        //final Set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
         
      if (indexPath.row == 11)
        {
        
         let Moremove:MoreViewController = self.storyboard?.instantiateViewController(withIdentifier: "MoreViewController") as! MoreViewController
                         self.navigationController?.pushViewController(Moremove, animated: true)
                        print("pass")
        }
        
        
        
       
        
//            let Moremove:MoreViewController = self.storyboard?.instantiateViewController(withIdentifier: "MoreViewController") as! MoreViewController
//             self.navigationController?.pushViewController(Moremove, animated: true)
//             print("pass")
//
        
    
        
    }
    
    
}


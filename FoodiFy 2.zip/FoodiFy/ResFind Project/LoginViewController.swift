//
//  LoginViewController.swift
//  ResFind Project
//
//  Created by NeelPurohit on 03/03/18.
//  Copyright © 2018 NeelPurohit. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

   
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var btnsignupwithFaceBook: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Sign In"
        
        let EmailImg = UIImage(named: "Email")
        let PassImg = UIImage(named: "Password")
        addImg(textField: txtEmail, andImage: EmailImg!)
        addImg(textField: txtPass, andImage: PassImg!)

        // Do any additional setup after loading the view.
    }
    func addImg(textField:UITextField, andImage Img:UIImage){
        
        // let leftimageview = UIImageView(Frame:CGRect(x: 0.0, y: 0.0, width:Img.size.width , height:Img.size.height ))
        let leftimageview = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: Img.size.width, height:Img.size.height))
        leftimageview.image = Img
        textField.leftView = leftimageview
        textField.leftViewMode = .always
        
    }
    
   /* func addImgToBtn(btn:UIButton ,andImage btnImg:UIImage)
    {
        let leftimagetobtn = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: btnImg.size.width, height: btnImg.size.height))
        leftimagetobtn.image = btnImg
        
        
    }*/


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func btnSignup(_ sender: UIButton) {
    
       
    
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

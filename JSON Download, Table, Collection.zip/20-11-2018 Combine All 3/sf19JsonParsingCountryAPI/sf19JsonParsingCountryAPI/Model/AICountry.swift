//
//  AICountry.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
//
//class AICountry: NSObject {
//
//}

struct AICountry {
    var name : String
    var capital : String
    var region : String
}

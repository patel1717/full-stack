//
//  TableViewCellCustom.swift
//  TableView
//
//  Created by SagarMac on 09/09/18.
//  Copyright © 2018 SagarMac. All rights reserved.
//

import UIKit

class TableViewCellCustom: UITableViewCell {

    @IBOutlet weak var lblNameTableViewCellCustom: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

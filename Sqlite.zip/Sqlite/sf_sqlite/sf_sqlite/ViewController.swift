//
//  ViewController.swift
//  sf_sqlite
//
//  Created by agile on 03/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import SQLite3

class ViewController: UIViewController {
    //MARK:- PROPERTIES
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    
    var db : OpaquePointer?
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        openConnection()
        createTable()
     
        //        ServiceManager.shared.openConnection()
        //        ServiceManager.shared.createTable()
        //        ServiceManager.shared.fetchData()
    }
    
    //MARK:- PRACTICE
    func openConnection() {
        let dirPath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first!
        let dbPath = dirPath.appending("/MyDatabase.sqlite")
        
        
        if sqlite3_open(dbPath, &db) == SQLITE_OK{
            print("database is connected .. \(dbPath)")
        }else{
            print("failed to create connection... \(getLatestError())")
        }
    }
    
    
    func getLatestError() -> String {
        return String.init(cString: sqlite3_errmsg(db))
    }
 
    
    func createTable(){
        let query = "CREATE TABLE Person(id INT, name CHAR(255), address CHAR(255))"
        var statement:OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nTable Created ")
        }else{
            print("failed to create Table : \(getLatestError())")
        }
        
        sqlite3_finalize(statement)
    }

    
    func insertData() {
        let id = 1
        let name = "saif"
        let address = "india"
        
        let query = "INSERT INTO Person(id, name, address) VALUES (\(id), '\(name)', '\(address)')"
        var statement :OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("data insert successfully")
        }else{
            print("failed to insert data : \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    func updateData()  {
        let query = "UPDATE Person SET address = 'US' WHERE address = 'india'"
        var statement : OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("record update successfully")
        }else{
            print("failed to update records...\(getLatestError())")
        }
        
        sqlite3_finalize(statement)
    }

    
    func deleteData()  {
        let query = "DELETE FROM Person WHERE id = 1;"
        var statement : OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("record deleted successfully")
        }
        else{
            print("failed to detele record... \(getLatestError())")
        }
    }
    
    
    func fetchData() {
        
        let query = "SELECT * FROM Person;"
        
        var statement : OpaquePointer?
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK{
            print("Query Result: ")
            
            while sqlite3_step(statement) == SQLITE_ROW{
                let id = sqlite3_column_int(statement, 0)
                
                
                let queryResultName = sqlite3_column_text(statement, 1)
                let name = String(cString: queryResultName!)
                
                
                let queryResultAddress = sqlite3_column_text(statement, 2)
                let address = String(cString: queryResultAddress!)
                
                print("\(id) |\(name) |\(address)")
            }
        }
        
    }
    
    func renameTable() {
        let query = "ALTER TABLE PersonUpdatedFinal RENAME TO PersonUpdatedFinal1;"
        var statement : OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("Table Successfully Rename")
        }else{
            print("Failed To Rename Table... \(getLatestError())")
        }
        
    }
    
    
    //MARK:- BUTTON ACTIONS btnInsert
    @IBAction func btnInsert(_ sender: Any) {
//    ServiceManager.shared.insertData()
        insertData()
    }

    //MARK:- BUTTON ACTIONS btnUpdate
    @IBAction func btnUpdate(_ sender: Any) {
//        ServiceManager.shared.updateData()
        updateData()
    }
    
    //MARK:- BUTTON ACTIONS btnDelete
    @IBAction func btnDelete(_ sender: Any) {
//        ServiceManager.shared.deleteData()
        deleteData()
    }
    
    //MARK:- BUTTON ACTIONS btnRename
    @IBAction func btnRename(_ sender: Any) {
//        ServiceManager.shared.renameTable()
        renameTable()
    }
    
    @IBAction func btnFetch(_ sender: Any) {
        fetchData()
    }
    
}


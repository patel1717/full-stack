//
//  MapController.swift
//  WebViewDemo
//
//  Created by agilemac-24 on 12/13/17.
//

import UIKit
import MapKit

class MapController: UIViewController,MKMapViewDelegate
{

    @IBOutlet weak var mapView: MKMapView!
    let regionRadius: CLLocationDistance = 1000

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

//        let artwork = MapAnnotation(title: "LDRP",
//                                    locationName: "LDRP Gandhinagar",
//                                    discipline: "",
//                                    coordinate: CLLocationCoordinate2D(latitude: 23.236344, longitude: 72.640099))
//        mapView.addAnnotation(artwork)

        let objAnnotation = NewAnnotation.init(withCoordination: CLLocationCoordinate2D(latitude: 23.236344, longitude: 72.640099))
        objAnnotation.strPinText = "1"
        objAnnotation.isDisplayCallOut = true
        objAnnotation.objStudent = Student()
        
        //objAnnotation.title = "Title"
//        objAnnotation.subtitle = "Sub Title"
        mapView.addAnnotation(objAnnotation)
        
//        let initialLocation = CLLocation(latitude: 23.236344, longitude: 72.640099)
//        centerMapOnLocation(location: initialLocation)
        
        
        mapView.delegate = self
        
        /*
        mapView.register(MapAnnotation.self, forAnnotationViewWithReuseIdentifier: "test")
        
        

        mapView.delegate = self
        // show artwork on map
        
        */
        // Do any additional setup after loading the view.
    }

    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
        //mapView.setCenter(location.coordinate, animated: true )
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.checkLocationAuthorizationStatus()
    }
    
    let locationManager = CLLocationManager()
    func checkLocationAuthorizationStatus() {
        if CLLocationManager.authorizationStatus() == .authorizedAlways {
            mapView.showsUserLocation = true
            
            
        } else {
            locationManager.requestAlwaysAuthorization()
            print("Not Permission")
            UIApplication.shared.open(URL(string:UIApplicationOpenSettingsURLString)!)

            
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        guard let annotation = annotation as? NewAnnotation else { return nil }
        // 2
       
        let identifier = "MapAnnotation"
        var view: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView
        { // 3
            dequeuedView.annotation = annotation
            view = dequeuedView
        }
        else
        {
            // 4
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.titleVisibility = .visible
            view.glyphText = annotation.strPinText
            view.canShowCallout = annotation.isDisplayCallOut
            
            view.calloutOffset = CGPoint(x: -5, y: 5)
            view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        return view
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,
                 calloutAccessoryControlTapped control: UIControl)
    {
       print("Callout called ")
        if let annotation = view.annotation as? NewAnnotation{
            print(annotation.coordinate)
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  FourthViewController.swift
//  JsonForHttp
//
//  Created by agile on 23/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {

    @IBOutlet weak var txtUserNameRegister: UITextField!
    @IBOutlet weak var txtPasswordRegister: UITextField!
    @IBOutlet weak var txtContactNoRegister: UITextField!
    @IBOutlet weak var txtEmailRegister: UITextField!
    @IBOutlet weak var txtDOBRegister: UITextField!
    @IBOutlet weak var txtCountryRegister: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func insertDataToApiPost() {
        let myUrl = URL(string: "http://mmoreward.com/User/UserLogin");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        
        
//        let postString = "UserName=\(String(describing: txtUserName.text!))&Password=\(String(describing: txtPassword.text!))";
        
        
//        print(postString)
//
//
//        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                return
            }
            
            
            print("response = \(String(describing: response))")
            
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                
                if let parseJSON = json as? [String:Any]{
                    let userValue = parseJSON["User"]
                    if let userInnerValue = userValue as? [String:Any] {
                        let userAllInnerValue = userInnerValue["ContactNo"]
                        print("Contact number :\(String(describing: userAllInnerValue))")
                    }
                    print("User Value : \(String(describing: userValue))")
                    print("Login SuccessFull")
                    print("json : \(parseJSON)")
                    
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }

    
    
    
    
    
    @IBAction func btnRegister(_ sender: Any) {
        
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = navigationController else {
            return
        }
        
        
        
        insertDataToApiPost()
        
//        ServiceManager.shared.fetchDataFromAPIPOST(urlstr: "http://mmoreward.com/User/UserRegistration") { (isSuccess, message, data) in
//            print("Success : \(isSuccess) ,Success Message: \(message) ,Data : \(data)")
//        }
        
        
        navigationController.pushViewController(thirdVC, animated: true)
        
    }
    
}

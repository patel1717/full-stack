//
//  ViewController.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView1: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView1.dataSource = self
        tableView1.delegate = self
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableView1.register(nibName, forCellReuseIdentifier: "Cell")
    }

    @IBAction func btnCallAPI(_ sender: Any) {
        
        ServiceManager.shared.fetchDataFromAPI(urlstr: "https://restcountries.eu/rest/v2/all") { (isSuccess, message, arrCountries) in
            if isSuccess {
                print(arrCountries)
                DispatchQueue.main.async {
                    self.tableView1.reloadData()
                }
            }else{
                print("Error : \(message)")
            }
        }
    }
}

extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.arrGloble.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView1.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCellCustom
        cell.lblCountryCellCustom.text = appDelegate.arrGloble[indexPath.row].name
        return cell
        
    }
}

extension ViewController : UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 62
    }
}

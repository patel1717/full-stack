//
//  ViewController.swift
//  sfWebViewDemo1
//
//  Created by agile on 19/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var webView1: WKWebView!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var reloadButton: UIButton!
    @IBOutlet weak var button2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        webView1.uiDelegate = self
        webView1.navigationDelegate = self
        
        let url = URL(string: "https://stackoverflow.com/questions/41162610/create-directory-in-swift-3-0")!
        
        webView1.load(URLRequest(url: url))
        
    }

    @IBAction func Button1(_ sender: Any) {
        if webView1.canGoBack{
            webView1.goBack()
        }
    }
    
    @IBAction func reloadButton(_ sender: Any) {
        if !webView1.isLoading {
            webView1.reload()
        }else{
            print("Still Loading... Refresh After Some Time")
        }
    }
    
    @IBAction func button2(_ sender: Any) {
        if webView1.canGoForward{
            webView1.goForward()
        }
    
    }
    


}

extension ViewController : WKNavigationDelegate{
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        print("Item \(navigationAction.navigationType.rawValue)")
        switch navigationAction.navigationType {
        case .backForward:
            print("BackForward")
            decisionHandler(.cancel)
            return
        case .reload:
            print("Reload")
            decisionHandler(.cancel)
            return
        default:
            decisionHandler(.allow)
            break
        }
    }
    
//    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
//        <#code#>
//    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!)
    {
        
        print("didStartProvisionalNavigation  : \(navigation)")
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!)
    {
        print("didReceiveServerRedirectForProvisionalNavigation : \(navigation)")
    }
    
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error)
    {
        print("didFailProvisionalNavigation \(error.localizedDescription)")
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!)
    {
        print("didCommit : \(navigation)")
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!)
    {
        print("didFinish : \(navigation.description)")
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error)
    {
        print("didFail navigation")
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView)
    {
        print("webViewWebContentProcessDidTerminate")
    }
}

extension ViewController : WKUIDelegate{
    
}


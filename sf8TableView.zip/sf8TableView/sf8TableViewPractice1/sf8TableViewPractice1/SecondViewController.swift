//
//  SecondViewController.swift
//  sf8TableViewPractice1
//
//  Created by agile on 15/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

  

}

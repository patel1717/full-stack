//
//  ViewController.swift
//  CoreData_TEST
//
//  Created by agile-2 on 23/11/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

  
    @IBAction func btnInsertPressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let personEntity = NSEntityDescription.entity(forEntityName: "Person", in: managedObjectContext)
        let object:NSManagedObject = NSManagedObject.init(entity: personEntity!, insertInto: managedObjectContext)
        
        object.setValue("Bob", forKey: "name")
        object.setValue(222, forKey: "idPerson")
        object.setValue(Date(), forKey: "birthDate")
        
        do {
            try managedObjectContext.save()
        }catch{
        }
        
    }
   
    @IBAction func btnFetchPressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Person")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for person in data {
                
                print("\n\n")
                print(person.value(forKey: "idPerson"))
                print(person.value(forKey: "name"))
                print(person.value(forKey: "birthDate"))
            }
            
        }catch {
            
        }

    }
    
    @IBAction func btnUpdatePressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Person")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for person in data {
                
                if let name = person.value(forKey: "name") as? String {
                    if name == "John" {
                        person.setValue("JOHN DOE", forKey: "name")
                    }
                }
            }
            
        }catch {
            
        }
        
        
        do {
            try manageContext.save()
        }catch{
        }


    }
    
    @IBAction func btnDeletePressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Person")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for person in data {
                
                if let name = person.value(forKey: "name") as? String {
                    if name == "Bob" {
                        manageContext.delete(person)
                    }
                }
            }
            
        }catch {
            
        }
        
        do {
            try manageContext.save()
        }catch{
        }


    }
}


//
//  ViewController.swift
//  sfExtraPractice
//
//  Created by agile on 04/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

protocol protocolTextFieldLengthChecker {
    func textFieldLengthCheck() -> Bool
    
}

class ViewController: UIViewController {

    
    @IBOutlet var txtNameFirstVC: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

  
    @IBAction func SegmentValueChanges(_ sender: UISegmentedControl) {
        
        print("Segment \(sender.selectedSegmentIndex) Selected")
        
    }
    
    
    @IBAction func SliderValueChanged(_ sender: UISlider) {
        
        print("Slider \(sender.value) , MIN \(sender.minimumValue) , MAX \(sender.maximumValue)")
    }
    
    @IBAction func SwitchValueChanged(_ sender: UISwitch) {
        
        print("Switch is \(sender.isOn)")
        
    }
    
    @IBAction func StepperValueChanged(_ sender: UIStepper) {
        
        print("Stepper \(sender.value)")
    }
    
    
    

    
    
    
    
    
    
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        if textFieldLengthCheck() {
            let secondVC  = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            
            guard let navigationController = self.navigationController else {
                return
            }
            
            navigationController.pushViewController(secondVC, animated: true)
            
            secondVC.FinalName = self.txtNameFirstVC.text!
        }else {
            self.displayAlert(message: "Please Enter Minimum 3 Character")
            }
    }
    
    
    
}



extension ViewController : protocolTextFieldLengthChecker
{
    func textFieldLengthCheck() -> Bool {
        
        if let count1 = txtNameFirstVC.text?.count
        {
            let isValid = count1 >= 3
            return isValid
        }else {
            return false
        }
    }
}





extension UIViewController {
    
    func displayAlert(message : String) {
        let alert = UIAlertController.init(title: "Alert", message: message, preferredStyle: .alert)
        
        present(alert, animated: true, completion: nil)
        
        
        let okButton = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
            print("txtNameFirst Alert Ok Button Pressed")
        })
        
        alert.addAction(okButton)
    }
    
}

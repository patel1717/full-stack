//
//  ViewController.swift
//  UserDefault_TEST
//
//  Created by agile-2 on 21/11/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

struct GlobalKeys {
    static let keyName = "keyName"
    static let keySwitch = "keySwitch"
}



class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var switchPreference: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doSetupUI()
//        enumTest()
    }
    
    //MARK:-  USER DEFAULTS
    func doSetupUI() {
        
        textField.autocorrectionType = .no
        
        if let keyName = UserDefaults.standard.object(forKey: GlobalKeys.keyName) {
            textField.text = keyName as? String
        }
        
        if let keySwitch = UserDefaults.standard.object(forKey: GlobalKeys.keySwitch) {
            switchPreference.isOn = keySwitch as! Bool
        }
    }

    @IBAction func btnSavePressed(_ sender: Any) {
    
        UserDefaults.standard.set(textField.text!, forKey: GlobalKeys.keyName)
        UserDefaults.standard.set(switchPreference.isOn, forKey: GlobalKeys.keySwitch)
        UserDefaults.standard.synchronize()
        
//        UserDefaults.standard.removeObject(forKey: GlobalKeys.keyName)
//        UserDefaults.standard.removeObject(forKey: GlobalKeys.keySwitch)
//        print("All defaults : \(UserDefaults.standard.dictionaryRepresentation())")
    }
    
    @IBAction func switchPressed(_ sender: Any) {
    }
}


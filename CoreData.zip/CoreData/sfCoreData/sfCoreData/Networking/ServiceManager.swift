//
//  ServiceManager.swift
//  sfCoreData
//
//  Created by agile on 29/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import CoreData

class ServiceManager: NSObject {

    static let shared : ServiceManager = ServiceManager()
    
    //MARK: FUNCTION INSERT
    func insertDataFromLocalDataBase(name : String, number :String)  {
       
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate
            else { return }
        
        
        let manageObjectContext = appDelegate.persistentContainer.viewContext
        
        let personEntity = NSEntityDescription.entity(forEntityName: "Person", in: manageObjectContext)
        let object : NSManagedObject = NSManagedObject(entity: personEntity!, insertInto: manageObjectContext)
        
        object.setValue(name, forKey: "name")
        object.setValue(number, forKey: "idPerson")
        object.setValue(Date(), forKey: "date")
        
    
        
        do {
            try manageObjectContext.save()
        } catch  {
            print("There is some problem")
        }
    }
    
    
    
    
    //MARK: FUNCTION FETCH
    func fetchDataFromLocalDataBase()  {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate
            else{
                return
        }
        
        let manageObjectContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        var fetchUniquId = NSFetchRequest<NSManagedObjectID>(entityName: "Person")
        print("Unique Id: \(fetchUniquId)")
        do{
            let data = try manageObjectContext.fetch(fetchRequest)
            
            for person in data{
                
           
                let model = AIData(name: person.value(forKey: "name") as! String, idPerson: person.value(forKey: "idPerson") as! String, date: person.value(forKey: "date") as! Date)
                appDelegate.arrayGloble.append(model)
                
                
                print("\n\n")
                
                print("data : \(person.value(forKey: "name"))")
                print("data : \(person.value(forKey: "idPerson"))")
                print("data : \(person.value(forKey: "date"))")
//                print("unique id : \(person.value(forKey: "_pk"))")
                print("data id :\(fetchUniquId)")
            }
        }catch{
            print("There is Some Problem")
            return
        }
    }
    
  
    
    
    //MARK: FUNCTION UPDATE
    func updateDataFromLocalDataBase()  {
      
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else
        {
            return
        }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Person")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for person in data {
                
                if let name = person.value(forKey: "name") as? String {
                    if name == "sa" {
                        person.setValue("sa DOE", forKey: "name")
                    }
                }
            }
            
        }catch {
            
        }
        
        
        do {
            try manageContext.save()
        }catch{
        }
        
    }
    
    
    
    
    //MARK: FUNCTION DELETE
    func deleteDataFromLocalDataBase()  {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate
            else{ return }
        
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest : NSFetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        do{
          let data = try managedObjectContext.fetch(fetchRequest)
            for person in data{
//                print(person.value(forKey: "name"))
                if let allName = person.value(forKey: "name") as? String{
                    if allName == "zzzzzz" {
                        
                        appDelegate.arrayGloble.removeAll()
                       let finalData = managedObjectContext.delete(person)
//
//                        let model = AIData(name: person.value(forKey: "name") as! String, idPerson: person.value(forKey: "idPerson") as! String, date: person.value(forKey: "date") as! Date)
//                        appDelegate.arrayGloble.append(model)
                    }
                }
                
            }
            
        }catch{
            
        }
        
        do{
            try managedObjectContext.save()
        }catch{
            
        }
        
        
    }
}

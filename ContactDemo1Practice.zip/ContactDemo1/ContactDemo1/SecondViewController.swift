//
//  SecondViewController.swift
//  ContactDemo1
//
//  Created by agile on 22/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet var tableViewSecondVC: UITableView!
    var arrRows : [String] = []
    var arrRowsDic : [String:String] = [:]
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpUI()
        doSetUpData()
    }
    
    private func doSetUpUI(){
        tableViewSecondVC.dataSource = self
        tableViewSecondVC.delegate = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableViewSecondVC.register(nibName, forCellReuseIdentifier: "Cell")
   
        
        // TITLE
        self.navigationItem.title = "Table Test"
        
        
        // BAR BUTTON ITEM
        
//        let leftBarButtonItem = UIBarButtonItem(title: "TEST", style: UIBarButtonItemStyle.plain, target: self, action: nil)
        
        
        let leftBarButtonItemBookmark = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(self.tabBarButton1))
        
        
        
        self.navigationItem.leftBarButtonItems = [leftBarButtonItemBookmark]
        
    
    
    }
    
    @objc func tabBarButton1(){
        print("Bar Button Pressed")
        let newRowToBeInserted = "NEW ROW"
        let indexToInsertAt = 0
        
        arrRows.insert(newRowToBeInserted, at: indexToInsertAt)
        
        let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
        
        tableViewSecondVC.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
    }

    private func doSetUpData(){
//        for i in 0 ..< 10{
//            arrRows.append("\(i)")
//        }
        
        
    }

    
    
//    @IBAction func barButtonInsertRow(_ sender: UIBarButtonItem) {
//
//        let newRowToBeInserted = "NEW ROW"
//        let indexToInsertAt = 0
//
//        arrRows.insert(newRowToBeInserted, at: indexToInsertAt)
//
//        let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
//
//        tableViewSecondVC.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
//
//    }
    
    
    
}

//MARK:- EXTENTION UITableViewDataSource
extension SecondViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewSecondVC.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        
        cell.lblNameTableViewCellCustom.text = arrRows[indexPath.row]
        return cell
    }
    
    
}

//MARK:- EXTENTION UITableViewDelegate
extension SecondViewController : UITableViewDelegate{
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let ThirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.pushViewController(ThirdVC, animated: true)
        ThirdVC.FinalName = arrRows[indexPath.row]
        print("This is \(indexPath.row) Row")
    }
    
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .insert{
//
//            if indexPath.row == nil{
//
//                let newRowToBeInserted = "NEW ROW"
//                let indexToInsertAt = 0
//
//                arrRows.insert(newRowToBeInserted, at: indexToInsertAt)
//
//                let indexPathToInsertAt = IndexPath(row: indexToInsertAt, section: 0)
//
//                tableViewSecondVC.insertRows(at: [indexPathToInsertAt], with: UITableViewRowAnimation.right)
//
//
//            }else {
//                print("Row can not be inserted")
//            }
//
//
//        }
//    }
}


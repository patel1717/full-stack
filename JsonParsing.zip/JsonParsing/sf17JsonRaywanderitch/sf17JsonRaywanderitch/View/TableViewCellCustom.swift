//
//  TableViewCellCustom.swift
//  sf17JsonRaywanderitch
//
//  Created by agile on 18/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class TableViewCellCustom: UITableViewCell {

    
    @IBOutlet weak var lblTitleCellCustom: UILabel!
    @IBOutlet weak var lblArtistCellCustom: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

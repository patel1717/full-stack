//
//  ViewController.swift
//  sf10ImagePicker
//
//  Created by agile on 02/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var imageViewTest: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func btnPickImage(_ sender: Any) {
        
        imageViewTest.image = UIImage(named: "nature")
        
//        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera){
//            let pickerImage = UIImagePickerController()
//            pickerImage.sourceType = .camera
//            pickerImage.allowsEditing = true
//            pickerImage.delegate = self
//            self.present(pickerImage, animated: true, completion: nil)
//        }else{
//            print("Camera Not Available")
//        }
       
        
    let pickerImage = UIImagePickerController()
        pickerImage.sourceType = .photoLibrary
        pickerImage.allowsEditing = true
        pickerImage.delegate = self
        self.present(pickerImage, animated: true, completion: nil)
    }
}

extension ViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image1 = info[UIImagePickerControllerEditedImage]
        
        self.imageViewTest.image = image1 as! UIImage
        self.dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("Picker was Cancel")
        self.dismiss(animated: true, completion: nil)
    }
}


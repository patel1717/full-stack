//
//  ForthVCViewController.swift
//  sf4practice
//
//  Created by agile on 27/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ForthVCViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   

    @IBAction func btnPop(_ sender: Any) {
        
//        navigationController?.popToRootViewController(animated: true)
        
        
        guard let navigationController = self.navigationController else {
            return
        }
   navigationController.popToViewController(navigationController.viewControllers[2], animated: true)
        
        
    }
}

//
//  ViewController.swift
//  DownloadTask_JsonParsing
//
//  Created by agile on 11/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation


class ViewController: UIViewController {

    
    //MARK :- PROPERTIES
    @IBOutlet weak var tableView1: UITableView!

    var searchResults: [Track] = []
   
    let downloadService = DownloadService()
    // Create downloadsSession here, to set self as delegate
    lazy var downloadsSession: URLSession = {
        //    let configuration = URLSessionConfiguration.default
        let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")
        return URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }()
    
    // Get local file path: download task stores tune here; AV player plays it.
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    func localFilePath(for url: URL) -> URL {
        return documentsPath.appendingPathComponent(url.lastPathComponent)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        imageView.image = UIImage(named: "nature")
        
        tableView1.dataSource = self
        tableView1.delegate = self
        
        let nibName = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableView1.register(nibName, forCellReuseIdentifier: "Cell")
    }
    
}




extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView1.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.lblTableViewCellCustom.text = "Row : \(indexPath.row)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 62.0
    }
    
    // When user taps cell, play the local file, if it's downloaded
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
print("Selected Row is \(indexPath.row)")
        
        
        //        let track = searchResults[indexPath.row]
//        if track.downloaded {
//            playDownload(track)
//        }
//        tableView.deselectRow(at: indexPath, animated: true)
    }
}





extension ViewController : DelegateTableViewCellCustom{
   
    func downloadTapped(_ cell: TableViewCellCustom){
        if let indexPath = tableView1.indexPath(for: cell) {
            let track = searchResults[indexPath.row]
            downloadService.startDownload(track)
            reload(indexPath.row)
        }
    }
    // Update track cell's buttons
    func reload(_ row: Int) {
        tableView1.reloadRows(at: [IndexPath(row: row, section: 0)], with: .none)
    }
    
    
}


//
//  ViewController.swift
//  Inspectable_TEST
//
//  Created by agile-2 on 17/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class MyLabel:UILabel {

    @IBInspectable var myColor:UIColor = UIColor.red
//    @IBInspectable var myFont:UIFont = UIFont.systemFont(ofSize: 18)
    @IBInspectable
    public var cornerRadius: CGFloat = 2.0 {
        didSet {
            self.layer.cornerRadius = self.cornerRadius
            self.clipsToBounds = true
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = myColor
    }
}


class ViewController: UIViewController {

    
    @IBOutlet weak var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        pageControl.currentPage = 8
    }

    
    @IBAction func pageControlChange(_ sender: UIPageControl) {
        
        print("value change \(sender.currentPage)")
    }
    
    
    func uploadFileTask() {
        
        var request = URLRequest(url: URL(string: "valid_url")!)
        request.httpMethod = "POST"
        request.setValue("", forHTTPHeaderField: "filename")
        
        
        let sessionConfig = URLSessionConfiguration.background(withIdentifier: "it.example.upload")
        sessionConfig.isDiscretionary = false
        sessionConfig.networkServiceType = .video
        let session = URLSession(configuration: sessionConfig, delegate: self , delegateQueue: OperationQueue.main)
        
        guard let image = UIImage(named: "ssss") else {
            return
        }
        
        guard let dataImage = UIImagePNGRepresentation(image) else {
            return
        }
        
        
        let task = session.uploadTask(with: request, from: dataImage)
        task.resume()
   
        
    }
}

extension ViewController : URLSessionDelegate {
    
    func urlSession(_ session: URLSession,
                    didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
    }
}


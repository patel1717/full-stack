//
//  ViewController.swift
//  POD_Demo
//
//  Created by agile on 02/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        doFetchDataFromAPI()
    }

    
    func doFetchDataFromAPI() {
        
        Alamofire.request("https://restcountries.eu/rest/v2/all").responseJSON { (response) in
            
            print("Request: \(String(describing: response.request))")   // original url request
            print("Response: \(String(describing: response.response))") // http url response
            print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
                print("JSON: \(json)") // serialized json response
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                print("Data: \(utf8Text)") // original server data as UTF8 string
            }
        }
    }
   

}


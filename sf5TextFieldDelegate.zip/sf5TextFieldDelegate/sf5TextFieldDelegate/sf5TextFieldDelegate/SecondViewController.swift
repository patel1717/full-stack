//
//  SecondViewController.swift
//  sf5TextFieldDelegate
//
//  Created by agile on 28/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

protocol protocolSecondVCDelegate {
    func saveWasPerformed(editedText:String)
    }



class SecondViewController: UIViewController {

    @IBOutlet var txtSendToFirstVC: UITextField!

    var Name: String = ""
    var delegate:protocolSecondVCDelegate?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.txtSendToFirstVC.text = Name
    }

    @IBAction func btnSendToFirstVC(_ sender: Any) {
        
    if let delegate = self.delegate, let text = txtSendToFirstVC.text
    {
        delegate.saveWasPerformed(editedText: text)
        navigationController?.popViewController(animated: true)
        
        
        }
        
    }
    
    @IBAction func btnPushToThirdVC(_ sender: Any) {
        
        let ThirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        
        navigationController.pushViewController(ThirdVC, animated: true)
        
    }
    
}

//
//  Student+CoreDataClass.swift
//  sf16JsonParsingAndSaveCoreData
//
//  Created by agile on 16/10/18.
//  Copyright © 2018 A. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}

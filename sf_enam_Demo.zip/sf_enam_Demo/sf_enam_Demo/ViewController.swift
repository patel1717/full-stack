//
//  ViewController.swift
//  sf_enam_Demo
//
//  Created by agile on 22/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

enum type1 : Int {
    case
    prepaid,
    postpaid,
    unlimited
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        planType(type: type1.prepaid.rawValue)
        planType(type: type1.unlimited.rawValue)
    }

    func planType(type: Int) {
        if type == type1.prepaid.rawValue{
            print("Prepaid")
        }
        if type == 1{
            print("Postpaid")
        }
        if type == 2{
            print("Unlimited")
        }
    }
    
}


//
//  ThirdViewController.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var modelToReceiveData : AICountry = AICountry(name: "name", capital: "capital", region: "region")
    
    //MARK:- PROPERTIES
    @IBOutlet weak var lblCapitalThirdVC: UILabel!
    @IBOutlet weak var lblRegionThirdVC: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblCapitalThirdVC.backgroundColor = StringConstant_File.shared.appButtonColor2
        lblRegionThirdVC.backgroundColor = StringConstant_File.shared.appButtonColor2
        
        self.lblCapitalThirdVC.text = "Capital : \(modelToReceiveData.capital)"
        self.lblRegionThirdVC.text = "Region : \(modelToReceiveData.region)"
     
    }


}

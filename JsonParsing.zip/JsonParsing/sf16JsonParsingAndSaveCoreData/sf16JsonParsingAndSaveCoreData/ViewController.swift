//
//  ViewController.swift
//  sf16JsonParsingAndSaveCoreData
//
//  Created by agile on 16/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let url = "www.google.com"
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnApiCall(_ sender: Any) {
        ServiceManager.shared.fetchData(url: url) { (isSucess, message, post) in
            print("API Status:\(isSucess), \n API Status Message:\(message), \n Total Number Of Posts Are : \(post.count), \n & Posts Are \(post)")
            
           
            
        }
    }
    
    @IBAction func btnSaveToCoreData(_ sender: Any) {
        ServiceManager.shared.fetchData(url: url) { (isSucess, message, post) in
            print("API Status:\(isSucess)")
        
        let dict = post
        ServiceManager.shared.save(Object: dict)
        
    }
    
    

}


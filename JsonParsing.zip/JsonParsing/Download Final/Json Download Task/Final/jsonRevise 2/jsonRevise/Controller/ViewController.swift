//
//  ViewController.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIDocumentInteractionControllerDelegate {

    
    @IBOutlet weak var btnDownload: UIButton!
    
    
//    @IBOutlet weak var tableView1: UITableView!
//    https://www.hq.nasa.gov/alsj/a17/A17_FlightPlan.pdf
    
    @IBOutlet weak var imageView1: UIImageView!
    
    // Get local file path: download task stores tune here; AV player plays it.
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    
    
    func localFilePath(for url: URL) -> URL {
        return documentsPath.appendingPathComponent(url.lastPathComponent)
        
    }

    
    var savedPdfPath = ""


    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnCallAPI(_ sender: Any) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        btnDownload.isEnabled = false
        
//         let url = URL(string: "https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg?cs=srgb&dl=light-landscape-nature-326055.jpg&fm=jpg")!
        let url = URL(string: "https://www.hq.nasa.gov/alsj/a17/A17_FlightPlan.pdf")!
        let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")
        let downloadsSession = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        let task: URLSessionDownloadTask = downloadsSession.downloadTask(with: url)
        task.resume()
    }

    @IBAction func btnShowPDF(_ sender: Any) {
        
        let dc = UIDocumentInteractionController(url: URL(fileURLWithPath: savedPdfPath))
        dc.delegate = self
        dc.presentPreview(animated: true)
    }

    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }

    
}


extension ViewController: URLSessionDownloadDelegate {
    

    
    // Stores downloaded file
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        // 1
        guard let sourceURL = downloadTask.originalRequest?.url else { return }
        // 2
        let destinationURL = localFilePath(for: sourceURL)
        savedPdfPath = destinationURL.path
        
        print(destinationURL)
        // 3
        let fileManager = FileManager.default
        
        // IF any old file is there than remove it
        try? fileManager.removeItem(at: destinationURL)
        
        do {
            try fileManager.copyItem(at: location, to: destinationURL)
        } catch let error {
            print("Could not copy file to disk: \(error.localizedDescription)")
        }

    }
    
    
    
    // Updates progress info
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        // 1
        
        // 2
        let progress = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
        // 3s
        let totalSize = ByteCountFormatter.string(fromByteCount: totalBytesExpectedToWrite,
                                                  countStyle: .file)
        
        print("Progress : \(progress), Total Size : \(totalSize)")
        
        DispatchQueue.main.async {
            if progress == 1 {
                self.btnDownload.isEnabled = true
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }else{
                UIApplication.shared.isNetworkActivityIndicatorVisible = true
                self.btnDownload.isEnabled = false
            }
        }
        
        
    
        
    
    }
    
}



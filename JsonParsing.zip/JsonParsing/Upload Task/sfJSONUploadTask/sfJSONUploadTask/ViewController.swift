//
//  ViewController.swift
//  sfJSONUploadTask
//
//  Created by agile on 19/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func uploadTask() {
        var request = URLRequest.init(url: URL(string: "Valid_Url")!)
        request.httpMethod = "POST"
        request.setValue(<#T##value: String?##String?#>, forHTTPHeaderField: <#T##String#>)
        
        var configuration = URLSessionConfiguration.background(withIdentifier: "background1")
        configuration.isDiscretionary = false
        configuration.networkServiceType = .video
        
        var urlSession = URLSession(configuration: configuration, delegate: self, delegateQueue: OperationQueue.main)
        
        guard let image1 = UIImage(named: "sssss") else {
            return
        }
        
        guard let dataImage = UIImagePNGRepresentation(image1!) else {
            return
        }
        
        urlSession.uploadTask(with: request, from: dataImage!)
        
        
    }
}

extension ViewController : URLSessionDelegate {
    
}


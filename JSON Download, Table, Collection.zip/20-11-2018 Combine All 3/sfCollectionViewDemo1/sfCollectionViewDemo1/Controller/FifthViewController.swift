//
//  FifthViewController.swift
//  sfCollectionViewDemo1
//
//  Created by agile on 21/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController {
    //MARK:- PROPERTIES
    @IBOutlet weak var lblNameTableView: UILabel!
    @IBOutlet weak var lblRegionTableView: UILabel!
    
    var nameFinal:String = ""
    var region: String = ""
    var model1:AICountry = AICountry(name: "", capital: "", region: "")
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()

//        lblNameTableView.text = nameFinal
//        lblRegionTableView.text = region
        lblNameTableView.text = model1.name
        lblRegionTableView.text = model1.region
    }
   
}

//
//  AIModel.swift
//  sf17JsonRaywanderitch
//
//  Created by agile on 18/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class AIModel: NSObject {
    let name : String
    let artist : String
    let previewURL : URL
    let index : Int
    let downloaded = false
    
    
    init(name1:String, artist1:String, previewURL1 : URL, index1: Int) {
        self.name = name1
        self.artist = artist1
        self.previewURL = previewURL1
        self.index = index1
        
    }
}


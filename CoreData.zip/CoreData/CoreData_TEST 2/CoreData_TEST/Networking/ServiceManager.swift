//
//  ServiceManager.swift
//  CoreData_TEST
//
//  Created by agile on 15/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import CoreData

class ServiceManager: NSObject {

    static let shared  : ServiceManager = ServiceManager()
    
    func insertDataToCoreData(name : String, number : String) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let manageObjectContext = appDelegate.persistentContainer.viewContext
        
        let personEntity = NSEntityDescription.entity(forEntityName: "Person", in: manageObjectContext)
        
        let object : NSManagedObject = NSManagedObject.init(entity: personEntity!, insertInto: manageObjectContext)

        object.setValue(name, forKey: "name")
        object.setValue(number , forKey: "idPerson")
        object.setValue(Date(), forKey: "birthDate")
        
        
        do{
        try manageObjectContext.save()
        }catch{
            print("Data was not saved")
        }
        
        
    }
    
    
    func fetchDataFromCoreData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let manageObjectContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest : NSFetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        do{
        let fetch = try manageObjectContext.fetch(fetchRequest)
            for finalFetchData in fetch{
                if let data = finalFetchData.value(forKey: "name"){
                    print("\n\n")
                    print("Data : \(data)")
                }
            }
            
        }catch{
            print("Data not find")
        }
        
        
    }
    
    
    func updateDataToCoreData(oldName : String, newName : String) {
        print("xyz")
    }
    
    
    func deleteDataFromCoreData(nameToBeDeleted : String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let manageObjectContext = appDelegate.persistentContainer.viewContext
        
        let fetch : NSFetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")
        
        do{
        let fetch2 =  try manageObjectContext.fetch(fetch)
            for finalFetch in fetch2{
                if let data = finalFetch.value(forKey: "name") as? String {
                    if data == nameToBeDeleted{
                        manageObjectContext.delete(finalFetch)
                    }
                }
            }
        }catch{
            print("Not fetch")
        }
        print("name \(nameToBeDeleted)")
        
        do {
            try manageObjectContext.save()
        } catch {
            print("Data Not Saved")
        }
        
    }
    
}

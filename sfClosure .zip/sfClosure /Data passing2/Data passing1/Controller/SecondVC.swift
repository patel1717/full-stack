//
//  SecondVC.swift
//  Data passing1
//
//  Created by agilemac-74 on 25/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    @IBOutlet var txtNameSecondVC: UITextField!
    @IBOutlet var txtNumberSecondVC: UITextField!
    

    
    var closureDemo2 : ((_ name:String , _ number:String) -> Void)?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
  
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
    
        navigationController.pushViewController(thirdVC, animated: true)
        
    }
    
    
    }




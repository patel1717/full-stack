//
//  ThirdViewController.swift
//  JsonForHttp
//
//  Created by agile on 23/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit




class ThirdViewController: UIViewController {

    static let shared : ThirdViewController = ThirdViewController()
    
    var closureSaveData : ((_ UserName:String, _ Password:String) -> Void)?
    
    
    
    @IBOutlet weak var txtUsernameLogin: UITextField!
    @IBOutlet weak var txtPasswordLogin: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("View Did Appear")
        txtUsernameLogin.text = ""
        txtPasswordLogin.text = ""
        
        
 
        
        
        
       
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        
      
        
        var model12 = AITest(UserName: txtUsernameLogin.text!, Password: txtPasswordLogin.text!)
        appDelegate.globalArrayTest.append(model12)
        
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        guard let navigationController = navigationController else {
            return
        }

        
        ServiceManager.shared.fetchDataFromAPIPOST(urlstr: "http://mmoreward.com/User/UserLogin") { (isSuccess, message, data) in
            print("Success : \(isSuccess) ,Success Message: \(message) ,Data : \(data)")
        }
        
        
        navigationController.pushViewController(secondVC, animated: true)
        
        print("test...test...test")
        appDelegate.globalArrayTest.remove(at: 0)
        
    }
    
    @IBAction func btnGotoRegister(_ sender: Any) {
    }
    
}

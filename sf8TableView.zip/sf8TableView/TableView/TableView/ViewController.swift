//
//  ViewController.swift
//  TableView
//
//  Created by SagarMac on 09/09/18.
//  Copyright © 2018 SagarMac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableViewTest: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doSetUpUI()
        print("viewDidLoad VIEW FRAME : \(self.tableViewTest.frame) ----- \(self.view.frame)")
    }
    
    private func doSetUpUI(){
        tableViewTest.dataSource = self
        tableViewTest.delegate = self
        
//        let nib = (nibName : "TableViewCellCustom" , bundle : nil)
        let customCellNib = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tableViewTest.register(customCellNib, forCellReuseIdentifier: "Cell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("viewWillAppear VIEW FRAME : \(self.tableViewTest.frame) ----- \(self.view.frame)")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear VIEW FRAME : \(self.tableViewTest.frame) ----- \(self.view.frame)")
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("viewDidLayoutSubviews VIEW FRAME : \(self.tableViewTest.frame) ----- \(self.view.frame)")
        
    }
    
    
    
    
    
    
}

extension ViewController : UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell =  tableViewTest.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.lblNameTableViewCellCustom.text = "Section \(indexPath.section) , Row \(indexPath.row)"
        
        return cell
    }
    
    
    
}

extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\n\nDid select row at indexpath : \(indexPath)")
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        
        switch section {
        case 0:
            viewHeader.backgroundColor = .red
        case 1:
            viewHeader.backgroundColor = .green
        case 2:
            viewHeader.backgroundColor = .blue
        default:
            viewHeader.backgroundColor = .magenta
        }
        
        let size = UIScreen.main.bounds
        
        
        
        let lblTitle = UILabel(frame: CGRect(x: 10, y: 10, width: size.width-20, height: 50))
        lblTitle.text = "Section \(section)"
        lblTitle.backgroundColor = .yellow
        lblTitle.textAlignment = .center
        
        viewHeader.addSubview(lblTitle)
        
        return viewHeader

        
        
        
        
//        let headerview = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 20))
//        headerview.backgroundColor = UIColor.brown
//
//        return headerview
        
        
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
//        let foterview = UIView(frame : CGRect())
        
                let footerview = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        
        switch section {
        case 0:
            footerview.backgroundColor = UIColor.red.withAlphaComponent(0.5)
        case 1:
            footerview.backgroundColor = UIColor.green.withAlphaComponent(0.5)
        case 2:
            footerview.backgroundColor = UIColor.blue.withAlphaComponent(0.5)
        default:
            footerview.backgroundColor = UIColor.magenta.withAlphaComponent(0.5)
        }
        
        return footerview

    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 50
    }
    
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return "Section \(section)"
//
//
//    }
    
    
}



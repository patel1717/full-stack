//
//  StringConstant File.swift
//  sf19JsonParsingCountryAPI
//
//  Created by agile on 23/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class StringConstant_File: NSObject {
    static let shared :StringConstant_File = StringConstant_File()
    
    var appBackgroundColor1 = #colorLiteral(red: 1, green: 0.8418819493, blue: 0.2535841549, alpha: 1)
    var appBackgroundColor2 = #colorLiteral(red: 1, green: 0.4050292492, blue: 0.4459997415, alpha: 1)
    var appButtonColor1 = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
    var appButtonColor2 = #colorLiteral(red: 0.3001987671, green: 0.3648431246, blue: 1, alpha: 1)
    
    var cellHighLightBackgroundColor = #colorLiteral(red: 1, green: 0.4050292492, blue: 0.4459997415, alpha: 1)
    
}

//
//  MenuViewController.swift
//  ResFind Project
//
//  Created by NeelPurohit on 06/03/18.
//  Copyright © 2018 NeelPurohit. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    
    var menuNameArr = [String]()
var iconImage = [UIImage]()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        menuNameArr = ["Pick Your City" , "Cuisines" , "Point of Interest" , "Special Deals" , "Favorites"]
        iconImage = [UIImage(named: "pick_your_city")!,UIImage(named: "cuisines")!,UIImage(named: "points_of_interest")!,UIImage(named: "price_tag")!,UIImage(named: "favourites")!]
       
        
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuNameArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "menuTableViewCell") as! menuTableViewCell
        cell.imgIcon.image = iconImage[indexPath.row]
        cell.lblMenuName.text! = menuNameArr[indexPath.row]
        return cell
        
    }
   /* func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //Set initial cell
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 100, 0)
        cell.layer.transform = transform
        
        //final Set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        }*/
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let revealViewController:SWRevealViewController = self.revealViewController()
        
        let cell:menuTableViewCell = tableView.cellForRow(at: indexPath) as! menuTableViewCell
        
        if cell.lblMenuName.text! == "Cuisines"
        {
            print(indexPath.row)
            print(cell.lblMenuName.text)
            
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let desController = mainStoryboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            let newFrontViewController = UINavigationController.init(rootViewController: desController)
           revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
            
        }
        if cell.lblMenuName.text! == "Point of Interest"
        {
            print(indexPath.row)
            print(cell.lblMenuName.text)
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let desController = mainStoryboard.instantiateViewController(withIdentifier: "PointofInterestViewController") as! PointofInterestViewController
            let newFrontViewController = UINavigationController.init(rootViewController: desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
           
        }
        if cell.lblMenuName.text! == "Pick Your City"
        {
            print(indexPath.row)
            print(cell.lblMenuName.text)
            
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let desController = mainStoryboard.instantiateViewController(withIdentifier: "PickCityViewController") as! PickCityViewController
            let newFrontViewController = UINavigationController.init(rootViewController: desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
            
            
        }
       
    }

}


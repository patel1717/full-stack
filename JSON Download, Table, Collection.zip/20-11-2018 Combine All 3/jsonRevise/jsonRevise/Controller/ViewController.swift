//
//  ViewController.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK:- PROPERTIES
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var btnDownloadImage: UIButton!
    @IBOutlet weak var btnDownloadPDF: UIButton!
    var savedPdfPath = ""
    let documentsPath = FileManager.default.urls(for: .documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask).first!
    
    func localFilePath(url : URL) -> URL {
        return documentsPath.appendingPathComponent(url.lastPathComponent)
    }
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()      
    }

   //MARK:- BUTTON IMAGE ACTIONS
    @IBAction func btnDownloadImage(_ sender: Any) {
        print("Download Image Pressed")
        let urlImg = URL(string: "https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg?cs=srgb&dl=light-landscape-nature-326055.jpg&fm=jpg")!
        let configurationImg = URLSessionConfiguration.background(withIdentifier: "bgImgSessionConfiguration")
        let DownloadSessionImg = URLSession(configuration: configurationImg, delegate: self, delegateQueue: nil)
        let taskImg : URLSessionDownloadTask = DownloadSessionImg.downloadTask(with: urlImg)
        taskImg.resume()
    }
    
    //InteractionController
    @IBAction func btnShowImage(_ sender: Any) {
        
        let show = UIDocumentInteractionController(url: URL(fileURLWithPath: savedPdfPath))
        show.delegate = self
        show.presentPreview(animated: true)
    }
    
   
    
    
    @IBAction func btnAttachImage(_ sender: Any) {
    
        ServiceManager.shared.fetchDataFromAPI(urlstr: "https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg?cs=srgb&dl=light-landscape-nature-326055.jpg&fm=jpg") { (isSuccess, message, imageDataFinal) in
            if isSuccess {
                print(imageDataFinal)
                print(message)
                
                DispatchQueue.main.async {
                    //                    self.tableView1.reloadData()
                    //                    self.imageView1.reloadInputViews()
                    
                    self.imageView1.image = imageDataFinal
                }
            }else{
                print("Error : \(message)")
            }
        }
    }
    
    
    
   //MARK:- BUTTON PDF ACTIONS
    @IBAction func btnDownloadPDF(_ sender: Any) {
        btnDownloadPDF.isEnabled = false
        UIApplication.shared.isNetworkActivityIndicatorVisible = true

        let url = URL(string: "https://www.hq.nasa.gov/alsj/a17/A17_FlightPlan.pdf")!
        let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")

        let downloadSession = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)

        let task : URLSessionDownloadTask = downloadSession.downloadTask(with: url)
        task.resume()
    }
    
    //InteractionController
    @IBAction func btnShowPDF(_ sender: Any) {
        let show = UIDocumentInteractionController(url: URL(fileURLWithPath: savedPdfPath))
        show.delegate = self
        show.presentPreview(animated: true)
    }
    
 
}

//MARK:- EXTENSION URLSessionDownloadDelegate
extension ViewController  : URLSessionDownloadDelegate{
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        
        guard let sourceUrl = downloadTask.originalRequest?.url else { return }
    
        let destinationUrl = localFilePath(url: sourceUrl)
        savedPdfPath = destinationUrl.path
        
        print(destinationUrl)
        
        let fileManager = FileManager.default
        
        try? fileManager.removeItem(at: destinationUrl)
        do{
            try fileManager.copyItem(at: location, to: destinationUrl)
        }catch let error{
            print("there some error \(error.localizedDescription)")
        }
    
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        
        let progress  = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
        
        let totalSize = ByteCountFormatter.string(fromByteCount: totalBytesExpectedToWrite, countStyle: ByteCountFormatter.CountStyle.file)
        
        print("Progress \(progress) & TotalSize\(totalSize)")
        
        DispatchQueue.main.async {
            if progress == 1 {
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                self.btnDownloadPDF.isEnabled = true
            }else{
                UIApplication.shared.isNetworkActivityIndicatorVisible = true
                self.btnDownloadPDF.isEnabled = false
            }
        }
    }
}

extension ViewController : UIDocumentInteractionControllerDelegate{
    
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }
    
}





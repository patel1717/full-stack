//
//  ViewController.swift
//  sf6RegistrationForm
//
//  Created by agile on 29/08/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit
//MARK:- PROTOCOLS
protocol protocolTextFieldLengthChecker{
    func textFieldLengthCheck() -> Bool
    func textFieldLengthCheck2() -> Bool
    func textFieldLengthCheck3() -> Bool
    func textFieldLengthCheck4() -> Bool
}

class ViewController: UIViewController {
    
 
    
   
    @IBOutlet var lblShow: UILabel!
    
    
    
    // MARK:- PROPERTIES
    @IBOutlet var txtUserNameFirstVC: UITextField!
    
    
    @IBOutlet var txtContactNoFirstVC: UITextField!
    
    
    @IBOutlet var txtEmailFirstVC: UITextField!
    
    
    @IBOutlet var txtPasswordFirstVC: UITextField!
    
    
    
    
    
    
    // MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
      
        print("viewDidLoad1")
        
        doSetupUI()
        
        lblShow.isHidden = true
        
    }

    private func doSetupUI(){
        
        self.txtUserNameFirstVC.delegate = self
        self.txtUserNameFirstVC.autocorrectionType = .no
        
        
        self.txtContactNoFirstVC.delegate = self
        self.txtContactNoFirstVC.keyboardType = .phonePad
        self.txtContactNoFirstVC.autocorrectionType = .no
    
        
        self.txtEmailFirstVC.delegate = self
        self.txtEmailFirstVC.keyboardType = .emailAddress
    self.txtEmailFirstVC.autocorrectionType = .no
        
        
        self.txtPasswordFirstVC.delegate = self
        self.txtPasswordFirstVC.autocorrectionType = .no
           self.txtPasswordFirstVC.returnKeyType = UIReturnKeyType.done
    
        
    }
    
    
    
    
    //MARK:- BUTTON CLICK
    @IBAction func btnSubmitRegistrationData(_ sender: Any) {
       
        if lblShow.isHidden == false{
            lblShow.isHidden = true
        }else{
            print("label must hide cause of button click")
        }
        
        var messages = ""
        
        if !textFieldLengthCheck() {
            messages = "Username Required Minimum length 3"
        }else if !textFieldLengthCheck2(){
            messages = "Please Enter 10 Digit in ddd-ddd-dddd formate"
        }else if !textFieldLengthCheck3(){
            messages = "Invalid email"
        }else if !textFieldLengthCheck4(){
            messages = "Wrong password"
        }
        
        if messages.isEmpty {
            let seconVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
            
            guard let navigationController = self.navigationController else {
                return
            }
            
            navigationController.pushViewController(seconVC, animated: true)
            
            seconVC.userName = txtUserNameFirstVC.text!
            seconVC.contactNo = txtContactNoFirstVC.text!
            seconVC.emailAddress = txtEmailFirstVC.text!
            seconVC.passWord = txtPasswordFirstVC.text!

        }else{
            self.displayAlert(message: messages)

        }
        
//
//        if textFieldLengthCheck(), textFieldLengthCheck2(), textFieldLengthCheck3(), textFieldLengthCheck4(){
//            let seconVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
//
//            guard let navigationController = self.navigationController else {
//                return
//            }
//
//            navigationController.pushViewController(seconVC, animated: true)
//
//            seconVC.userName = txtUserNameFirstVC.text!
//            seconVC.contactNo = txtContactNoFirstVC.text!
//            seconVC.emailAddress = txtEmailFirstVC.text!
//            seconVC.passWord = txtPasswordFirstVC.text!
//        }else {
//           self.displayAlert(message: "Please Enter Minimum 3 Character")
//
//
//
//
//        }
        
      
        
    }
    
    
    

}


















 //MARK:- VALIDATION



extension ViewController : protocolTextFieldLengthChecker{
   
//    func isEmail() -> Bool {
//        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
//        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
//        return emailTest.evaluate(with: self)
//    }
//
    
    
    func textFieldLengthCheck() -> Bool {
        if let count1 = txtUserNameFirstVC.text?.count{
            let isValid = count1 >= 3
            return isValid
        }else{
            
            return false
           
        }
    }
    
    func textFieldLengthCheck2() -> Bool {
//        let PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
//        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
//        return phoneTest.evaluate(with: self)
        
        
        let PHONE_REGEX: String
        PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
        return NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX).evaluate(with: txtContactNoFirstVC.text!)
    }
    
    

    
    func textFieldLengthCheck3() -> Bool {
        
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: txtEmailFirstVC.text!)
       

    }
    
    
    func textFieldLengthCheck4() -> Bool {
        if let count4 = txtPasswordFirstVC.text?.count{
            let isValid = count4 >= 3
            return isValid
        }else{
           
            return false
            
        }
    }
    
    
    
}



extension UITextField
{
    func myCustomMethod() {
        
        
        
    }
    
}

//MARK:- TEXTFIELD DELEGATE
extension ViewController : UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("SHOULD BEGIN")
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("DID BEGIN")
        
        if lblShow.isHidden == true {
            lblShow.isHidden = false
        }else{
            print("label can not show")
        }
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        print("SHOULD END EDITING")
        return true
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
       
        let emailtext = self.txtEmailFirstVC.text!
        
        if emailtext.isEmpty
        {
            print("Please Enter Email")
        }else
        {
            print("Now Email is Not Empty")
        }
        
        print("DID END EDITING WITH REASON")
    }
    

    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("SHOULD RETURN")
        
       
        textField.myCustomMethod()
        
        
        textField.resignFirstResponder()
    
        return true
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        print("SHOULD CLEAR")
        
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        print("TEXT FIELD RANGE = \(range) & STRING = \(string)")

        return true
       
    }

}



extension UIViewController
{
    func displayAlert(message : String)
    {
        let alert = UIAlertController.init(title: "Alert", message: message, preferredStyle: .alert)
        present(alert, animated: true, completion: nil)
        
        let okButton = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
            print("Alert ok Button Pressed")
        })
        
        alert.addAction(okButton)
    }
}



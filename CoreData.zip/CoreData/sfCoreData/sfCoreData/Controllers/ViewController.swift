//
//  ViewController.swift
//  sfCoreData
//
//  Created by agile on 28/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtId: UITextField!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super .viewDidAppear(true)
        let sa = "saaaa"
        print(sa)
        appDelegate.arrayGloble.removeAll()
        print(appDelegate.arrayGloble)
    }

    //MARK:- BUTTON ACTIONS INSERT
    @IBAction func insertData(_ sender: Any) {
        ServiceManager.shared.insertDataFromLocalDataBase(name : txtName.text!, number: txtId.text!)
    }
    
    
    //MARK:- BUTTON ACTIONS FETCH
    @IBAction func FetchData(_ sender: Any) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        guard let navigationController = navigationController else {
            return
        }
        ServiceManager.shared.fetchDataFromLocalDataBase()
        
        navigationController.pushViewController(secondVC, animated: true)
    }
    
    
    //MARK:- BUTTON ACTIONS UPDATE
    @IBAction func updateData(_ sender: Any) {
        ServiceManager.shared.updateDataFromLocalDataBase()
    }
    
    //MARK:- BUTTON ACTIONS DELETE
    @IBAction func deletedData(_ sender: Any) {
        ServiceManager.shared.deleteDataFromLocalDataBase()
    }
    
    
    
    
}


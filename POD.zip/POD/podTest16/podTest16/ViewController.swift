//
//  ViewController.swift
//  podTest16
//
//  Created by agile on 16/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import AlamofireImage

class ViewController: UIViewController {

    @IBOutlet weak var imageView1: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDataFromAPI()
        fetchImageFromAPI()
        downloadImageFromAPI()
    }
    
    //SDWebImage (can set)
    func fetchImageFromAPI() {
        imageView1.sd_setImage(with: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRACVO6G7Gs5S-E4PbcqmQW8Gx30nHYXMigekwEagZzY8pooqk"), placeholderImage: UIImage(named: ""))
    }
    
    //AlomofireImage (can download & can set also)
    func downloadImageFromAPI(){
        let downloader = ImageDownloader()
        let urlRequest = URLRequest(url: URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRACVO6G7Gs5S-E4PbcqmQW8Gx30nHYXMigekwEagZzY8pooqk")!)
        
        downloader.download(urlRequest) { response in
            print(response.request)
            print(response.response)
            debugPrint(response.result)
            
            if let image = response.result.value {
                print(image)
            }
        }
    }
    
    
    //Alamofire
    func fetchDataFromAPI() {
        Alamofire.request("https://restcountries.eu/rest/v2/all").responseJSON { (response) in
//            print("Request\(String(describing: response.request))")
//            print("Responce\(String(describing: response.response))")
//            print("Result\(response.result)")
            
            
            if let json = response.result.value {
  //                print("Json \(json)")
                if let allArray = json as? NSArray{
                    for eachDict in allArray{
                        if let dict1 = eachDict as? [String:Any]{
                            if let name = dict1["name"]{
//                                 print("Country Name : \(name)")
                            }
                        }
                    }
                }
                
                
                //                if let jsonFinal = json as? Array<Dictionary<String,Any>> {
//                 let countryName = jsonFinal[0]["name"]
//                 print("JSON:    countryName: \(countryName)")
//                }
                
            }
            
            if let data = response.data, let utf81 = String(data: data, encoding: .utf8){
//                print("Data \(utf8)")
                
                if let data1 = data as? NSArray {
                    if let allArray = data1 as? NSArray{
                        for eachDict in allArray{
                            if let dict1 = eachDict as? [String:Any]{
                                if let name = dict1["name"]{
//                                    print("Country Name : \(name)")
                                }
                            }
                        }
                    }
                }
            }
            
     
        }
    }

}





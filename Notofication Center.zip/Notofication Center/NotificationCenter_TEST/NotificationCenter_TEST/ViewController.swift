//
//  ViewController.swift
//  NotificationCenter_TEST
//
//  Created by agile-2 on 14/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

extension Notification.Name {
    static let eventXYZ = "eventXYZ"
}

class ViewController: UIViewController {

    @IBOutlet weak var lblTest: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        lblTest.text = "Hello World"
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.notificationHandler(notification:)),
                                               name: NSNotification.Name(rawValue: NSNotification.Name.eventXYZ),
                                               object: nil)
    }


    @objc func notificationHandler(notification:Notification) {
        if let userInfo = notification.userInfo {
            print("Event handled in FIRST VC WITH DATA : \(userInfo)")
        }else{
            print("Event handled in FIRST VC")
        }
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: NSNotification.Name.eventXYZ), object: nil)
        
    }
    
    
    @IBAction func btnChangeAttributePressed(_ sender: Any) {
    
        let str = self.lblTest.text!
        
        let attributedString = NSMutableAttributedString(string: str, attributes: nil)
        let helloRange = (attributedString.string as NSString).range(of: "Hello")
        attributedString.setAttributes([NSAttributedStringKey.foregroundColor : UIColor.red], range: helloRange)
        attributedString.setAttributes([NSAttributedStringKey.backgroundColor : UIColor.magenta], range: helloRange)
//        attributedString.setAttributes([NSAttributedStringKey.font : UIFont.systemFont(ofSize: 23)], range: helloRange)

        lblTest.attributedText = attributedString

        
        
        
        //let baseString = "Don't use magic numbers."
        
        //let attributedString = NSMutableAttributedString(string: baseString, attributes: nil)
        
        //let dontRange = (attributedString.string as NSString).range(of: "Don't")
        //attributedString.setAttributes([NSFontAttributeName: UIFont.boldSystemFont(ofSize: 18)], range: dontRange)

        
        
        
    }
    
    @IBAction func btnPressed(_ sender: Any) {
        
        
    }


}


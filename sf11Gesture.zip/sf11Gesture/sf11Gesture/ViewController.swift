//
//  ViewController.swift
//  sf11Gesture
//
//  Created by agile on 04/10/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK:- PROPERTIES
    @IBOutlet var uiViewTest: UIView!
    @IBOutlet var longPressGesture: UILongPressGestureRecognizer!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGestureDemo = UITapGestureRecognizer(target: self, action: #selector(self.tapGestureHandler(sender:)))
        tapGestureDemo.numberOfTapsRequired = 2
//        tapGestureDemo.numberOfTouchesRequired = 2
        uiViewTest.addGestureRecognizer(tapGestureDemo)
        
        let panGestureDemo  = UIPanGestureRecognizer(target: self, action: #selector(self.panGestureHandler(sender:)))
        uiViewTest.addGestureRecognizer(panGestureDemo)
        
        let pinchGestureDemo = UIPinchGestureRecognizer(target: self, action: #selector(self.pinchGestureHandler(sender:)))
        uiViewTest.addGestureRecognizer(pinchGestureDemo)
        
        
        let swipeGestureDemo = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeGestureHandler(sender:)))
        swipeGestureDemo.direction = .left
        uiViewTest.addGestureRecognizer(swipeGestureDemo)
        
        panGestureDemo.require(toFail: swipeGestureDemo)
        
        uiViewTest.addGestureRecognizer(longPressGesture)
        
        
        let rotationGestureDemo = UIRotationGestureRecognizer(target: self, action: #selector(self.rotationGestureHandler(sender:)))
        uiViewTest.addGestureRecognizer(rotationGestureDemo)
    }

    //MARK:- GESTURE SELECTORS
    @objc private func tapGestureHandler(sender:UIGestureRecognizer) {
        print("Tap Gesture Active")
        uiViewTest.backgroundColor = UIColor.brown
    }
    
    @objc private func panGestureHandler(sender:UIGestureRecognizer){
        print("Pan Gesture Active")
    }
    
    
    @objc private func pinchGestureHandler(sender:UIGestureRecognizer){

        switch sender.state {
        case .began:
            print("PINCH BEGAN")
        case .changed:
            print("PINCH CHANGED")
        case .ended:
            print("PINCH ENDED")
        default:
            return
        }
        
        //        print("Pinch Gesture Active")
    }
    
    @objc private func swipeGestureHandler(sender:UIGestureRecognizer){
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as!SecondViewController
        guard let navigationController = self.navigationController else {
            return
        }
        navigationController.pushViewController(secondVC, animated: true)
        
        print("Swipe Gesture Active")
    }
    
    @objc private func rotationGestureHandler(sender:UIGestureRecognizer){
        print("rotaion Gesture Active")
    }
    
    //MARK:- ACTIONS
    @IBAction func longPressGestureAction(_ sender: UILongPressGestureRecognizer) {
        print("Long Press Gesture Active")
        
    }
    
}


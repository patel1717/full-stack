//
//  ViewController.swift
//  Icon_TEST
//
//  Created by agile-2 on 12/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//
import UIKit

class ViewController: UIViewController {

public final class IconFont {
    private class func iconFont(_ size: CGFloat) -> UIFont? {
        if size == 0.0 {
            return nil
        }
        let iconfont = "my_iconfont"
        loadMyCustomFont(iconfont)
        return UIFont(name: iconfont, size: size)
    }
    private class func loadMyCustomFont(_ name:String) {
        guard let fontPath = Bundle(for: IconFont.self).path(forResource: name, ofType: "ttf") else {
            return
        }
        
        var error: Unmanaged<CFError>?
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: fontPath)) , let provider = CGDataProvider(data: data as CFData) else {
            return
        }
        
        let font = CGFont(provider)
        CTFontManagerRegisterGraphicsFont(font!, &error)
        if error != nil {
            return
        }
    }
}
    
}

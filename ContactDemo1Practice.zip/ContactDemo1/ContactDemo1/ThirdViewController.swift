//
//  ThirdViewController.swift
//  ContactDemo1
//
//  Created by agile on 22/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet var txtNameThirdVC: UITextField!
    @IBOutlet var txtNumberThirdVC: UITextField!
    
    var FinalName : String = ""
    
      //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
      self.txtNameThirdVC.text = FinalName
        
    }
    
    

   
}

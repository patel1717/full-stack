//
//  ViewController.swift
//  Sqlite_TEST
//
//  Created by agile-2 on 28/11/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import SQLite3

class ViewController: UIViewController {

    var db : OpaquePointer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        openConnection()
        //createTable()
        
        fetchData()
        
        renameTable()
    }

    func openConnection() {
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        let dbPath = dirPath.appending("/MyDatabase.sqlite")

        if sqlite3_open(dbPath, &db) == SQLITE_OK {
            print("\nDatabase connected... : \(dbPath)")
        }else{
            print("Failed to create connection : \(getLatestError())")
        }
    }
    
    func getLatestError() -> String {
        return String.init(cString: sqlite3_errmsg(db))
    }
    
    func createTable() {
        
        let query = "CREATE TABLE Person(id INT, name CHAR(255), address CHAR(255)   )"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nTable created")
        }else{
            print("\nFailed to create table : \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    func insertData() {
        
//        let id = 3
//        let name = "Smith"
//        let address = "Canada"
        
        let id = 4
        let name = "John"
        let address = "Ahmedabad"
        
        let query = "INSERT INTO Person(id, name, address) VALUES (\(id),'\(name)','\(address)')"
        print("Insert Query : \(query)")
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nInsert done")
        }else{
            print("\nFailed to insert record : \(getLatestError())")
        }

        sqlite3_finalize(statement)
    }
    
    func fetchData() {
        
        var queryStatement: OpaquePointer? = nil
        let queryStatementString = "SELECT * FROM Person;"

        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            
            print("Query Result:")

            while sqlite3_step(queryStatement) == SQLITE_ROW {
                
                let id = sqlite3_column_int(queryStatement, 0)
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 1)
                let name = String(cString: queryResultCol1!)
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 2)
                let address = String(cString: queryResultCol2!)
                
                
                print("\(id) | \(name) | \(address)")
            }
        } else {
            print("SELECT statement could not be prepared : \(getLatestError())")
        }
        sqlite3_finalize(queryStatement)
    }
    
    func updateData() {
        
        let query = "UPDATE Person SET address = 'US' WHERE address = 'United State'"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nUpdate done")
        }else{
            print("\nFailed to update record : \(getLatestError())")
        }

        sqlite3_finalize(statement)
    }
    
    func deleteData() {
        
        let query = "DELETE FROM Person WHERE Id = 3;"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nDelete done")
        }else{
            print("\nFailed to delete record : \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    func renameTable() {
        
        let query = "ALTER TABLE Person RENAME TO PersonUpdated;"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nRename done")
        }else{
            print("\nFailed to rename table : \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    
    @IBAction func btnInsertPressed(_ sender: Any) {
        insertData()
    }
    
    @IBAction func btnUpdatePressed(_ sender: Any) {
        updateData()
    }
    
    @IBAction func btnDeletePressed(_ sender: Any) {
        deleteData()
    }
    
    


}


//
//  SecondViewController.swift
//  sfCollectionViewDemo1
//
//  Created by agile on 20/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class SecondViewController : UIViewController {
    //MARK:- PROPERTIES OF COLLECTION VIEW
    @IBOutlet weak var collectionView1: UICollectionView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpCollectionView()
    }
    
    func doSetUpCollectionView() {
        collectionView1.delegate = self
        collectionView1.dataSource = self
        
        let nibName1 = UINib(nibName: "CollectionViewCellCustom", bundle: nil)
        collectionView1.register(nibName1, forCellWithReuseIdentifier: "Cell")
        
        let flowLayout = UICollectionViewFlowLayout()
         flowLayout.scrollDirection = .horizontal
        collectionView1.collectionViewLayout = flowLayout
    }
}

//MARK:- EXTENSION UICollectionViewDataSource
extension SecondViewController : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return appDelegate.globalArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView1.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCellCustom
        
        cell.lblCollectionViewCellCustom.text = appDelegate.globalArray[indexPath.row].name
        return cell
        
    }
    
}

//MARK:- EXTENSION UICollectionViewDelegate
extension SecondViewController : UICollectionViewDelegate{
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Item didSelectItemAt \(indexPath.item)")
        
//        let fifthVC = self.storyboard?.instantiateViewController(withIdentifier: "FifthViewController") as! FifthViewController
         let fourthVC = self.storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        guard let navigationController = navigationController else {
            return
        }
        fourthVC.capital = appDelegate.globalArray[indexPath.row].capital
        fourthVC.region = appDelegate.globalArray[indexPath.row].region
        //        fifthVC.model1 = appDelegate.globalArray[indexPath.row]
        
        navigationController.pushViewController(fourthVC, animated: true)
        
        //    let cell3 = collectionView1.beginInteractiveMovementForItem(at: indexPath) as! CollectionViewCellCustom
        
        
        //    let cell4 = collectionView1.cellForItem(at: indexPath) as! CollectionViewCellCustom
        //   cell4.uiView12.backgroundColor = UIColor.darkGray
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        print("Item didDeselectItemAt \(indexPath.item)")
        //        let cell3 = collectionView1.beginInteractiveMovementForItem(at: indexPath) as! CollectionViewCellCustom
        
        
        //    let cell4 = collectionView1.cellForItem(at: indexPath) as! CollectionViewCellCustom
        //        cell4.uiView12.backgroundColor = StringConstant_File.shared.cellBackgroundColor
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        print("Item didHighlightItemAt \(indexPath.item)")
        
        
        let cell4 = collectionView1.cellForItem(at: indexPath) as! CollectionViewCellCustom
        cell4.uiView12.backgroundColor = StringConstant_File.shared.cellHighLightBackgroundColor
    }
    
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        print("Item shouldSelectItemAt \(indexPath.item)")
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, shouldDeselectItemAt indexPath: IndexPath) -> Bool {
        print("Item shouldDeselectItemAt \(indexPath.item)")
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        print("Item shouldHighlightItemAt \(indexPath.item)")
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        print("Item willDisplay \(indexPath.item)")
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        print("Item didEndDisplaying \(indexPath.item)")
    }
}


//MARK:- EXTENSION UICollectionViewDelegateFlowLayout
extension SecondViewController : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //        print("Size : \(collectionView.frame.size)")
        let size1 = CGSize(width: 200, height: 200)
        return size1
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 30
    }
    
    
    
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
    //        return 10
    //    }
    //
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
    //        return UIEdgeInsets.init(top: 20, left: 20, bottom: 20, right: 20)
    //    }
    
}


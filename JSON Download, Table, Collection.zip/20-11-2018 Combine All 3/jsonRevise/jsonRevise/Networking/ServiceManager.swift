//
//  ServiceManager.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ServiceManager: NSObject {

    let image2  = UIImage()
    static let shared : ServiceManager = ServiceManager()
    typealias closureComplition = ((Bool,String,UIImage) -> Void)
    
    
    func fetchDataFromAPI(urlstr : String , complition : @escaping closureComplition) {
        guard let url = URL(string: urlstr) else {
            complition(false, "url Not Get", image2)
            return
        }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, responce, error) in
            if let err = error{
                complition(false, "Error : \(err)", self.image2)
                return
            }
            
            if let imageData = data {
 
                let jsonImage  = UIImage(data: imageData)

                complition(true, "Got API responce Successfully", jsonImage!)
                
            }else{
                complition(false, "Not Get",self.image2)
                return
            }
        }
        dataTask.resume()
        
    }
    
}

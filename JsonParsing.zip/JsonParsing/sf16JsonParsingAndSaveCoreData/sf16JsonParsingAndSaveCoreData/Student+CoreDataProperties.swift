//
//  Student+CoreDataProperties.swift
//  sf16JsonParsingAndSaveCoreData
//
//  Created by agile on 16/10/18.
//  Copyright © 2018 A. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var userId: String?
    @NSManaged public var id: String?
    @NSManaged public var title: String?
    @NSManaged public var body: String?

}

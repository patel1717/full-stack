//
//  AITest.swift
//  JsonForHttp
//
//  Created by agile on 26/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

struct AITest {
    var UserName : String
    var Password : String
}

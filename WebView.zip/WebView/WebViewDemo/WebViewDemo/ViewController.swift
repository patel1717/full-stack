//
//  ViewController.swift
//  WebViewDemo
//
//  Created by agilemac-24 on 12/12/17.
//

import UIKit
import WebKit
import CoreLocation
class SecondViewController:ViewController{
    override func test() {
        
    }
}

class ViewController: UIViewController,WKNavigationDelegate,WKUIDelegate
{

    @IBOutlet var objWebView:WKWebView!
    var locationManager:CLLocationManager = CLLocationManager()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        objWebView.navigationDelegate = self
        objWebView.uiDelegate = self
        //objWebView.load(URLRequest.init(url: URL.init(string: "https://www.google.com")!))
//        let strHTML:String = "<HTML><HEAD> </HEAD><body>Hello World</body> </HTML>"
//        objWebView.loadHTMLString(strHTML, baseURL: nil)
        
        let url = URL(string: "https://stackoverflow.com/questions/49628954/how-to-load-url-on-wkwebview")!
        objWebView.load(URLRequest(url: url))
        //self.view = objWebView
        // Do any additional setup after loading the view, typically from a nib.
    }

    func test(){
        
    }
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnForward: UIButton!
    @IBOutlet weak var btnRefresh: UIButton!
    
    @IBAction func btnBackPressed(_ sender: Any) {
        if objWebView.canGoBack {
            objWebView.goBack()
        }
    }
    
    @IBAction func btnForwardPressed(_ sender: Any) {
        if objWebView.canGoForward {
            objWebView.goForward()
        }
    }
    
    @IBAction func btnRefreshPressed(_ sender: Any) {
        if !objWebView.isLoading {
            objWebView.reload()
        }else{
            print("Still loading... please refresh after sometime")
        }
    }


    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        
        print("\n\nAction : ",navigationAction.navigationType.rawValue)
        
        switch navigationAction.navigationType {
            
        case .linkActivated:
            print("linkActivated")
//            if navigationAction.targetFrame == nil {
//                webView.load(navigationAction.request)// It will load that link in same WKWebView
//            }
        case .backForward:
            print("backforward")
            decisionHandler(.cancel)
            return;

        case .formResubmitted:
            print("formResubmitted")
        case .formSubmitted:
            print("formSubmitted")
        case .reload:
            print("reload")
            decisionHandler(.cancel)
            return;
        case .other:
            print("other")
//        default:
//            print("default")
            break
        }
        
        if let url = navigationAction.request.url {
            print("Url : ",url.absoluteString) // It will give the selected link URL
        }
        decisionHandler(.allow)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        
        decisionHandler(.allow)
    }

     func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!)
     {
        
        print("didStartProvisionalNavigation  : \(navigation)")
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
 
     func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!)
     {
        print("didReceiveServerRedirectForProvisionalNavigation : \(navigation)")
    }
    

     func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error)
     {
        print("didFailProvisionalNavigation \(error.localizedDescription)")
    }
     func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!)
     {
        print("didCommit : \(navigation)")
    }
     func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!)
     {
        print("didFinish : \(navigation.description)")
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
     func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error)
     {
        print("didFail navigation")
    }
     func webViewWebContentProcessDidTerminate(_ webView: WKWebView)
     {
        print("webViewWebContentProcessDidTerminate")
    }

}


//
//  ViewController.swift
//  jsonRevise
//
//  Created by agile on 12/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//    @IBOutlet weak var tableView1: UITableView!
    
    @IBOutlet weak var imageView1: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }

    @IBAction func btnCallAPI(_ sender: Any) {
        
        ServiceManager.shared.fetchDataFromAPI(urlstr: "https://images.pexels.com/photos/326055/pexels-photo-326055.jpeg?cs=srgb&dl=light-landscape-nature-326055.jpg&fm=jpg") { (isSuccess, message, arrImage) in
            if isSuccess {
                print(arrImage)
                print(message)
                DispatchQueue.main.async {
//                    self.tableView1.reloadData()
//                    self.imageView1.reloadInputViews()
                    
                    self.imageView1.image = arrImage
                }
            }else{
                print("Error : \(message)")
            }
        }
    }
}



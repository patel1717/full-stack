//
//  ThirdViewController.swift
//  Data passing1
//
//  Created by agile on 12/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet var txtNameThirdVC: UITextField!
    @IBOutlet var txtNumberThirdVC: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func btnDone(_ sender: UIButton) {
        let firstVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.popToRootViewController(animated: true)
        
        
    }


}

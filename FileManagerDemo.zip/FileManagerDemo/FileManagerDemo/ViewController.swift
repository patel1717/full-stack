//
//  ViewController.swift
//  FileManagerDemo
//
//  Created by agile on 01/01/01.
//  Copyright © 2001 neeall. All rights reserved.
//

import UIKit

class ViewController: UIViewController  {
   
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBOutlet var imgselect: UIImageView!
    @IBAction func saveimg(_ sender: Any) {
        let DocUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        print(DocUrl?.absoluteString ?? "nil")
        let imageurl = DocUrl?.appendingPathComponent("yu.png")
        
        let img = UIImage(named: "yuvraj")
        
        do{
            try UIImagePNGRepresentation(img!)?.write(to: imageurl!)
        }
        catch{
            
        }
    }
    
    @IBAction func Getbtn(_ sender: Any) {
        
        let a1: UIAlertController = UIAlertController(title: "Action Sheet", message: "Choose Any Option", preferredStyle: .actionSheet)
        
        let a2: UIAlertAction = UIAlertAction(title: "Cancel" , style: .cancel) {
            action -> Void in
        }
        a1.addAction(a2)
        
        let done: UIAlertAction = UIAlertAction(title: "done", style: .default){
            action -> Void in
            self.getImage()
        }
        a1.addAction(done)
        self.present(a1,animated: true,completion: nil)
        
    }
    
    func getImage() {
        let d1 = FileManager.SearchPathDirectory.documentDirectory
        let d2 = FileManager.SearchPathDomainMask.userDomainMask
        let d3 = NSSearchPathForDirectoriesInDomains(d1, d2, true)
        
       if let d4 = d3.first {
            let d5 = URL(fileURLWithPath:d4).appendingPathComponent("yu.png")
        let fm = FileManager.default
        
        if fm.fileExists(atPath: d5.path){
            print("File Avaliable")
            let image = UIImage(contentsOfFile: d5.path)
            
            imgselect.image = image
            
        }
        else{
            print("File Not Avaliable")
            }
        }
    }
    
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//        <#code#>
//    }
//
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//        <#code#>
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


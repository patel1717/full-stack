//
//  ViewController.swift
//  Map_TEST
//
//  Created by agile-2 on 05/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import MapKit

//class Artwork: NSObject, MKAnnotation {
//    let title: String?
//    let locationName: String
//    let discipline: String
//    let coordinate: CLLocationCoordinate2D
//
//    init(title: String, locationName: String, discipline: String, coordinate: CLLocationCoordinate2D) {
//        self.title = title
//        self.locationName = locationName
//        self.discipline = discipline
//        self.coordinate = coordinate
//
//        super.init()
//    }
//
//    var subtitle: String? {
//        return locationName
//    }
//}


class ViewController: UIViewController {

    @IBOutlet weak var mapViewTEST: MKMapView!
    let regionRadius: CLLocationDistance = 1000

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapViewTEST.delegate = self
    }

    
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius, regionRadius)
        mapViewTEST.setRegion(coordinateRegion, animated: true)
        
    }
    
    @IBAction func setRegionPressed(_ sender: Any) {
        
//        let initialLocation = CLLocation(latitude: 22.307278, longitude: 73.18229444)
//        centerMapOnLocation(location: initialLocation)

        
        let annotation = MKPointAnnotation()
        let centerCoordinate = CLLocationCoordinate2D(latitude: 22.407278, longitude:73.18229444)
        annotation.coordinate = centerCoordinate
        annotation.title = "VADODARA 1"
        mapViewTEST.addAnnotation(annotation)
        
        centerMapOnLocation(location: CLLocation(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude))

        
    }
    
    @IBAction func testPressed(_ sender: Any) {
        
        let annotation = MKPointAnnotation()
        let centerCoordinate = CLLocationCoordinate2D(latitude: 22.307278, longitude:73.18229444)
        annotation.coordinate = centerCoordinate
        annotation.title = "VADODARA"
        mapViewTEST.addAnnotation(annotation)
        
        centerMapOnLocation(location: CLLocation(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude))
    }
    

}

extension ViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let identifier = "marker"
        var view: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: -5, y: 5)

            let tempView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            tempView.backgroundColor = .red

            let tempView1 = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            tempView1.backgroundColor = .green

            view.rightCalloutAccessoryView = tempView
            view.leftCalloutAccessoryView = tempView1
        }
        return view
    }
}

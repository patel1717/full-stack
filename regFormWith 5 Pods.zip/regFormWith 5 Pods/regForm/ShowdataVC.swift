//
//  ShowdataVC.swift
//  regForm
//
//  Created by agile on 01/01/01.
//  Copyright © 2001 agile.New. All rights reserved.
//

import UIKit

class ShowdataVC: UIViewController {

    @IBOutlet var LblFirstname: UILabel!
    
    @IBOutlet var LblLastName: UILabel!
    
    @IBOutlet var LblEmail: UILabel!
    
    @IBOutlet var LblContact: UILabel!
    
    @IBOutlet var LblAddress: UILabel!
    
    @IBOutlet var LblCity: UILabel!
    
    @IBOutlet var LblState: UILabel!

    @IBOutlet var LblZipcode: UILabel!
    
    var strFirstname:String! = nil
    var strLastname:String! = nil
    var stremail:String! = nil
    var strcontact:String! = nil
    var straddress:String! = nil
    var strcity:String! = nil
    var strstate:String! = nil
    var strzipcode:String! = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        LblFirstname.text = strFirstname
        LblLastName.text = strLastname
        LblEmail.text = stremail
        LblContact.text = strcontact
        LblAddress.text = straddress
        LblCity.text = strcity
        LblState.text = strstate
        LblZipcode.text = strzipcode
        }
        
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

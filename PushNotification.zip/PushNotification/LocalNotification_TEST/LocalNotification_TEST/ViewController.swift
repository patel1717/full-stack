//
//  ViewController.swift
//  LocalNotification_TEST
//
//  Created by agile-2 on 07/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import UserNotifications


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    func askPermission() {
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert]) { (granted, error) in
            
            if granted {
                self.setupLocalNotification()
            }else{
                print("\n\nError : \(String(describing: error?.localizedDescription))")
            }
        }
    }
    
    func setupLocalNotification() {
        
        let content = UNMutableNotificationContent()
        content.title = "This is Title"
        content.body = "This is Body"
        content.sound = UNNotificationSound.default()
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        
        
        let request = UNNotificationRequest(identifier: "identifier_one", content: content, trigger: trigger)
        
    
        
        UNUserNotificationCenter.current().add(request) { (err) in
            if (err != nil){
                print("\nThere was an error while adding notificaion request : \(String(describing: err?.localizedDescription))")
            }else{
                print("\nRequest added successfully")
            }
        }
        
        UNUserNotificationCenter.current().delegate = self
        
    }
    
    @IBAction func btnPressed(_ sender: Any) {
        
        askPermission()
    }
    

}

extension ViewController : UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        print("\nWill present notification : \(notification)")
        
        if notification.request.identifier == "identifier_one" {
            completionHandler([.alert, .sound, .badge])
        }else{
            completionHandler([])
        }
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        print("\nDid receive response of notification : \(response.notification)")
    }
    
    
    
}



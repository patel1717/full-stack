//
//  SecondViewController.swift
//  sf4DelegateProtocolWithPushViewController
//
//  Created by agile on 25/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

protocol SecondVCDelegate{
    
    func saveWasPerformed(editedText:String)
}


class SecondViewController: UIViewController {

    
    
    
    
    @IBOutlet var txtNameSecondVC: UITextField!
    
    
    
    var name :String = ""
    var delegate:SecondVCDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
self.txtNameSecondVC.text = name
       
    }

  
    @IBAction func btnSaveAndSendToFirstVC(_ sender: Any) {
        
        if let delegate = self.delegate , let text = txtNameSecondVC.text{
            
            delegate.saveWasPerformed(editedText: text)
            
            self.navigationController?.popViewController(animated: true)
  
        }
        }
        
        
    
    
    @IBAction func PushToThirdVC(_ sender: Any) {
        
       let ThirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        navigationController?.pushViewController(ThirdVC, animated: true)
        
        
        
        
    }
}

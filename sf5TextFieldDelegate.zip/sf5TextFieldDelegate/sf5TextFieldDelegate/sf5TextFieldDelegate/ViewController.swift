//
//  ViewController.swift
//  sf5TextFieldDelegate
//
//  Created by agile on 28/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

protocol protocolMinLengthChecker {
    func minLengthCheck() -> Bool
}


class ViewController: UIViewController {
   
    
    
    
    
    

    //MARK:- PROPERTIES
    @IBOutlet var txtNameFirstVC: UITextField!
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

   
    //MARK:- BUTTON EVENTS
    
    @IBAction func btnSendToSecondVC(_ sender: Any) {
        
       
        
        
        if minLengthCheck(){
        
        
        let SecondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.pushViewController(SecondVC, animated: true)
        
        
        SecondVC.Name = self.txtNameFirstVC.text!
      SecondVC.delegate = self
        
        }else{
            //FIXME:- USE ALERT
            print("alert1")
            
            let alert = UIAlertController.init(title: "Alert", message: "Please Enter Minimum 3 Characters", preferredStyle: .alert)
            
            present(alert, animated: true, completion: nil)
            
            let OktxtNameFirstVC = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                print("Ok txtNameFirstVC Pressed")
                
            })
            
            alert.addAction(OktxtNameFirstVC)
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }
    

}





extension ViewController : protocolMinLengthChecker{
    
    //MARK:- VALIDATION
    
    func minLengthCheck() -> Bool {
        if let count1 = txtNameFirstVC.text?.count{
            let isValid = count1 >= 3
            return isValid
        }else{
            return false
        }
    }
    
    
}


extension ViewController : protocolSecondVCDelegate {
    
    func saveWasPerformed(editedText: String) {
        txtNameFirstVC.text = editedText
    }
    
}


extension ViewController : UITextFieldDelegate{
}



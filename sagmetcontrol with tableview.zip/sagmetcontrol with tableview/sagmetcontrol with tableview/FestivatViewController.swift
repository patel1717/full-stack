//
//  FestivatViewController.swift
//  sagmetcontrol with tableview
//
//  Created by agilemac-74 on 20/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class FestivatViewController: UIViewController {

    @IBOutlet var img: UIImageView!
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblCity: UILabel!
    
    var ahData:AhmedabadModel?
    var muData:MumbaiModel?
    var baData:BangloreModel?
    var puData:PuneModel?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if ahData?.city == "City :- Ahmedabad"{
          img.image = ahData?.image
            lblTitle.text = ahData?.title
            lblCity.text = ahData?.city
        }
        
    }

   

}

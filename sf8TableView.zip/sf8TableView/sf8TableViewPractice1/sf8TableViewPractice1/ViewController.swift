//
//  ViewController.swift
//  sf8TableViewPractice1
//
//  Created by agile on 13/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK:- PROPERTIES
    @IBOutlet var TableviewTest: UITableView!
    var arrRowsInsert = [String]()
    
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpUI()
        doSetUpData()
}
    //MARK:- VIEW LIFE CYCLE doSetUpUI
    private func doSetUpUI(){
        TableviewTest.dataSource = self
        TableviewTest.delegate = self
        let nib = UINib(nibName:"TableViewCellCustom", bundle:nil)
        TableviewTest.register(nib, forCellReuseIdentifier: "Cell")
        
        //Title
        self.navigationItem.title = "Title 1"
        
        //BAR BUTTON ITEM
        let leftBarButton1 = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(barButtonItem))
        
        self.navigationItem.leftBarButtonItem = leftBarButton1
    }

    @objc func barButtonItem(){
        print("bar Button Pressed")
    }
   
    //MARK:- VIEW LIFE CYCLE doSetUpData
    private func doSetUpData(){
        for i in 0 ..< 10{
            arrRowsInsert.append("Number Of Rows \(i)")
        }
    }
    
    //MARK:- VIEW LIFE CYCLE BarButton
    @IBAction func barButtonInsertRow(_ sender: Any) {
        print("Insert Presssed")
    
        let indexToInsertAt = 2
        let newRowToBeInsert = "Inserted 2nd Row"
        
        arrRowsInsert.insert(newRowToBeInsert, at: indexToInsertAt)
       let indexpathToInsertAt = IndexPath(row:indexToInsertAt, section:0)
        TableviewTest.insertRows(at: [indexpathToInsertAt], with: UITableViewRowAnimation.automatic)
    }
    
}




//MARK:- EXTENSION UITableViewDataSource
extension ViewController : UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrRowsInsert.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       let cell =  TableviewTest.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        cell.btnTemp.tag = indexPath.row
        cell.btnTemp.addTarget(self, action: #selector(btnAction(sender:)), for: .touchUpInside)
        cell.closureForPass = {
            
        }
        cell.lblNameTableViewCellCustom.text = arrRowsInsert[indexPath.row]
        return cell
    }
    @objc func btnAction(sender:UIButton){
    print("test\(sender.tag)")
    }
}

//MARK:- EXTENSION UITableViewDelegate
extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame : CGRect(x:0, y:0, width:10, height:10))
        headerView.backgroundColor = UIColor.blue.withAlphaComponent(0.8)
        
        let screenWidth = UIScreen.main.bounds
        
        let lblHV = UILabel(frame : CGRect(x:10, y:10, width:screenWidth.width-20, height:50))
        lblHV.backgroundColor = UIColor.yellow
        lblHV.text = "Section Name \(section)"
        lblHV.textAlignment = .center
        
        headerView.addSubview(lblHV)
        
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 80
    }
    
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x:0, y:0, width:10, height:10))
        footerView.backgroundColor = UIColor.darkGray.withAlphaComponent(0.5)
        return footerView
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arrRowsInsert.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.left)
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("This is \(indexPath.row) Row")
        
        let SecondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.pushViewController(SecondVC, animated: true)
    }
    
    
}


//
//  ViewController.swift
//  TabelVIewPracticeDeleteRow
//
//  Created by agile on 11/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tabelViewTest: UITableView!
    var arrSections:[[String]] = []
    var arrOfSecton1Rows:[String] = []
    var arrOfSecton2Rows:[String] = []
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        doSetUpUI()
        doSetUpData()
    }

    private func doSetUpUI(){
        tabelViewTest.dataSource = self
        tabelViewTest.delegate = self
        let nibuse = UINib(nibName:"TableViewCellCustom", bundle:nil)
        tabelViewTest.register(nibuse, forCellReuseIdentifier: "Cell")
    }
    
    private func doSetUpData(){
        for i in 0..<30{
            if i < 10{
        arrOfSecton1Rows.append("This is cell number \(i)")
            }
        arrOfSecton2Rows.append("This is cell number \(i)")
        }
        arrSections.append(arrOfSecton1Rows)
        arrSections.append(arrOfSecton2Rows)
    }
    
}

//MARK:- EXTENSION UITableViewDataSource
extension ViewController : UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrSections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        let arrrows = arrSections[section]
        return arrrows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tabelViewTest.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
//        let arrRows = arrSections[indexPath.section]
        cell.lblNameTabelViewCellCustom.text = arrSections[indexPath.section][indexPath.row]
        
        return cell
    }
    
    
}

//MARK:- EXTENSION UITableViewDataSource
extension ViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
       //MARK:- FIX ME WIDTH
        let headerView = UIView(frame: CGRect(x:0, y:0, width:10, height:50))
 headerView.backgroundColor = UIColor.darkGray
        
        //        switch section {
//        case 0:
//            headerView.backgroundColor = UIColor.blue
//        case 1:
//            headerView.backgroundColor = UIColor.brown
//        case 2:
//            headerView.backgroundColor = UIColor.cyan
//        default:
//            headerView.backgroundColor = UIColor.darkGray
//        }
        let size = UIScreen.main.bounds
        let lblHeader = UILabel(frame: CGRect(x:10, y:10, width:size.width-20, height:50))
        lblHeader.text = "Section \(section)"
        lblHeader.backgroundColor = UIColor.yellow
        lblHeader.textAlignment = .center
        
        headerView.addSubview(lblHeader)
        
        return headerView
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }


    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x:0, y:0, width:10, height:10))
        footerView.backgroundColor = UIColor.darkGray.withAlphaComponent(0.5)
        return footerView
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 40
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arrSections[indexPath.section].remove(at: indexPath.row)
            tabelViewTest.deleteRows(at: [indexPath], with: UITableViewRowAnimation.none)
        }
    }
}


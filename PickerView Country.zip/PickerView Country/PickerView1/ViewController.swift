//
//  ViewController.swift
//  PickerView1
//
//  Created by agile on 17/09/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

struct country : Decodable {
    let name : String
}

class ViewController: UIViewController {

    //MARK:- PROPERTIES
    
    @IBOutlet var lblNamePickerView: UILabel!
    @IBOutlet var txtFieldForPickerView: UITextField!
    @IBOutlet var pickerViewTest: UIPickerView!
    @IBOutlet var datePicker1: UIDatePicker!
    
    @IBOutlet var lblForDatePicker: UILabel!
    
    
    var countries = [country]()

   
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
      doSetUpUI()
        doSetUpData()
//        txtFieldForPickerView.inputView = pickerViewTest
        
        pickerViewTest.dataSource = self
        pickerViewTest.delegate = self
    }
    
      //MARK:- VIEW LIFE CYCLE doSetUpUI
    private func doSetUpUI(){
        pickerViewTest.isHidden = true
      
        
        self.txtFieldForPickerView.delegate = self
        txtFieldForPickerView.font = UIFont.monospacedDigitSystemFont(ofSize: 26, weight: UIFont.Weight(rawValue: 5))
        txtFieldForPickerView.placeholder = "Select Data Form Pickerview"
        txtFieldForPickerView.textAlignment = .center
        
        datePicker1.backgroundColor = UIColor.yellow.withAlphaComponent(0.7)
        datePicker1.addTarget(self, action: #selector(dateValueChangeHandler(datePickerDate1:)), for: UIControlEvents.valueChanged)
    }
    
    @objc func dateValueChangeHandler(datePickerDate1 : UIDatePicker){
    print("Date \(datePickerDate1.date)")
        self.lblForDatePicker.text = "\(datePickerDate1.date)"
        
    }
    
    
    //MARK:- VIEW LIFE CYCLE doSetUpData
    private func doSetUpData(){
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error == nil {
                do{
                    self.countries = try JSONDecoder().decode([country].self, from: data!)
                }catch{
                    print("Error")
                }
                
                DispatchQueue.main.async {
                    self.pickerViewTest.reloadComponent(0)
                }
                print(self.countries.count)
            }
            }.resume()
    }

    
}



//MARK:- EXTENSION UIPickerViewDataSource
extension ViewController : UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countries.count
    }
    
    
}

//MARK:- EXTENSION UIPickerViewDelegate
extension ViewController : UIPickerViewDelegate{
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("Row \(row)  Component \(component)")
        
        if countries.count >= 1 {
            lblNamePickerView.text = countries[row].name
            txtFieldForPickerView.text = countries[row].name
            if pickerView.isHidden == false {
                pickerView.isHidden = true
            }
        }else {
            print("Countries Are Not Present in Database")
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countries[row].name
    }
//    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
//
//        let pickerUiView = UIView(frame : CGRect(x:0, y:0, width:100, height:150))
//        pickerUiView.backgroundColor = UIColor.red
//
//        return pickerUiView
//    }

}

//MARK:- EXTENSION

extension ViewController : UITextFieldDelegate{

    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("DidBegin")

        if pickerViewTest.isHidden == true {
            pickerViewTest.isHidden = false
        }else{
            print("ahd")
        }
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if pickerViewTest.isHidden == true {
            pickerViewTest.isHidden = false
        }else {
            print("textField Not being edit till now")
        }
        return true
    }
}



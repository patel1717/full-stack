//
//  MoreViewController.swift
//  ResFind Project
//
//  Created by NeelPurohit on 15/02/18.
//  Copyright © 2018 NeelPurohit. All rights reserved.
//

import UIKit

class MoreViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    

    
    var MoreFoodName = ["BBQ","Desert","Gulten Friendly","French","Greek","Latin","Indian","Koshar","Vegan"]
    var morefoodimg = [#imageLiteral(resourceName: "BBQ1"),#imageLiteral(resourceName: "Dessert1"), #imageLiteral(resourceName: "Gluten Friendly"),#imageLiteral(resourceName: "French1"),#imageLiteral(resourceName: "Greek3"),#imageLiteral(resourceName: "Latin3"),#imageLiteral(resourceName: "indian5"),#imageLiteral(resourceName: "Koshar1"),#imageLiteral(resourceName: "Vegan2")]

    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MoreFoodName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let morecell = tableView.dequeueReusableCell(withIdentifier: "MoreCell") as! MoreTableViewCell
        morecell.morefoodname?.text = MoreFoodName[indexPath.row]
        morecell.MoreImg?.image = morefoodimg[indexPath.row]
        return morecell
    
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //Set initial cell
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 100, 0)
        cell.layer.transform = transform
        
        //final Set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
        }
    

}
}

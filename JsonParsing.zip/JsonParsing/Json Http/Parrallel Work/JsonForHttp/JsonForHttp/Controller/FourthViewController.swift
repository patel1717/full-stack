//
//  FourthViewController.swift
//  JsonForHttp
//
//  Created by agile on 23/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {

    @IBOutlet weak var txtUserNameRegister: UITextField!
    @IBOutlet weak var txtPasswordRegister: UITextField!
    @IBOutlet weak var txtContactNoRegister: UITextField!
    @IBOutlet weak var txtEmailRegister: UITextField!
    @IBOutlet weak var txtDOBRegister: UITextField!
    @IBOutlet weak var txtCountryRegister: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func insertDataToApiPost() {

        let username : String = txtUserNameRegister.text!
        let password : String = txtPasswordRegister.text!
        let contactNo : String = txtContactNoRegister.text!
        let email : String = txtEmailRegister.text!
        let country : String = txtCountryRegister.text!
        let active : Bool = true
        
        
//
//        let parameters: [String: Any] = ["UserName": txtUserNameRegister.text!, "Password": txtPasswordRegister.text!, "ContactNo": txtContactNoRegister.text!, "Email": txtEmailRegister.text!, "Country": txtCountryRegister.text!, "IsActive": true]
//
//
        
        //create the url with URL
        let url = URL(string: "http://mmoreward.com/User/UserRegistration")! //change the url
        
        //create the session object
        let session = URLSession.shared
        
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "POST" //set http method as POST
//
//        let postString = "UserName=Saif5124&Password=Saif5124&ContactNo=45454445468&Email=Saif5124test@gmail.com&Country=india";
        let postString = "UserName=\(username)&Password=\(password)&ContactNo=\(contactNo)&Email=\(email)&Country=\(country)&IsActive=\(active)";

        print(postString)
        //        let postString = "UserName=Sagar&Password=sagar";
        request.httpBody = postString.data(using: String.Encoding.utf8);

        
        
        //
//        do {
//            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
//
//        } catch let error {
//            print(error.localizedDescription)
//        }
        //
        
        
        
        
        
        
//        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    // handle json...
                }
                
            } catch let error {
                print(error.localizedDescription)
            }
        })
        task.resume()
    }

    
    
    
    
    @IBAction func btnRegister(_ sender: Any) {
        
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        
        guard let navigationController = navigationController else {
            return
        }
        
        insertDataToApiPost()
        
//        ServiceManager.shared.fetchDataFromAPIPOST(urlstr: "http://mmoreward.com/User/UserRegistration") { (isSuccess, message, data) in
//            print("Success : \(isSuccess) ,Success Message: \(message) ,Data : \(data)")
//        }
        
        
        navigationController.pushViewController(thirdVC, animated: true)
        
    }
    
}

//
//  SecondViewController.swift
//  sf6RegistrationForm
//
//  Created by agile on 29/08/18.
//  Copyright © 2018 vishal2421. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var txtNameSeccondVC: UITextField!
    
    @IBOutlet var txtContactSeccondVC: UITextField!
    
    
    @IBOutlet var txtEmailSeccondVC: UITextField!
    
    @IBOutlet var txtPassSeccondVC: UITextField!
    
    var userName : String = ""
    var contactNo : String = ""
    var emailAddress : String = ""
    var passWord : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    self.txtNameSeccondVC.text = userName
        self.txtContactSeccondVC.text = contactNo
        self.txtEmailSeccondVC.text = emailAddress
        self.txtPassSeccondVC.text = passWord
    }

    
    
    

}

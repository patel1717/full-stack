//
//  ForthViewController.swift
//  sf5TextFieldDelegate
//
//  Created by agile on 28/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ForthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnPop(_ sender: Any) {
        
        
        
if let allVC = navigationController?.viewControllers
{
    
    let secondVC = allVC[1]
    
    if secondVC is SecondViewController{
    
    navigationController?.popToViewController(secondVC, animated: true)
    }
    
        }
        
        
//        navigationController?.popToViewController(navigationController?.viewControllers[1], animated: true)
        
        

        
        
    }
    
}

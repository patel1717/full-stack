//
//  ThirdViewController.swift
//  JsonForHttp
//
//  Created by agile on 23/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit




class ThirdViewController: UIViewController {

    static let shared : ThirdViewController = ThirdViewController()
    
    @IBOutlet weak var txtUsernameLogin: UITextField!
    @IBOutlet weak var txtPasswordLogin: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("View Did Appear")
        txtUsernameLogin.text = ""
        txtPasswordLogin.text = ""
        
        
        appDelegate.globalArrayTest.removeAll()
        
       
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        
//        var model12 = AITest(UserName: txtUsernameLogin.text!, Password: txtPasswordLogin.text!)
//        appDelegate.globalArrayTest.append(model12)
        var user : AITest = AITest()
        user.UserName
        
        let fourthVC = self.storyboard?.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        
        guard let navigationController = navigationController else {
            return
        }

        
        ServiceManager.shared.fetchDataFromAPIPOST(urlstr: "http://mmoreward.com/User/UserLogin") { (isSuccess, message, data) in
            print("Success : \(isSuccess) ,Success Message: \(message) ,Data : \(data)")
        }
        
        
        navigationController.pushViewController(fourthVC, animated: true)
        
    }
    
    @IBAction func btnGotoRegister(_ sender: Any) {
    }
    
}

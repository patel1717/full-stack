//
//  ViewController.swift
//  JsonSimpleCall
//
//  Created by agile on 22/10/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit

struct AIPost : Decodable{
    var name = String()
    var capital = String()
    var region = String()
}

class ViewController: UIViewController {

    var aiPostArray = [AIPost]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnCall(_ sender: Any) {
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
        
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do{
                self.aiPostArray = try JSONDecoder().decode([AIPost].self, from: data!)
                
                for allArrayFinal in self.aiPostArray{
                 
                    print(allArrayFinal.name)
                }
                
            }catch{
                print("error")
            }
        }.resume()
    }
    
    
}


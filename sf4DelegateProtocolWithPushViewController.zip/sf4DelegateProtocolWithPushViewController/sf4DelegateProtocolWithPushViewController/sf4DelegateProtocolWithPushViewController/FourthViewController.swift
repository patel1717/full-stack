//
//  FourthViewController.swift
//  sf4DelegateProtocolWithPushViewController
//
//  Created by agile on 25/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {

    @IBOutlet var txtNameForthVC: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
    @IBAction func btnPop(_ sender: Any) {
        
        guard let navigationController = self.navigationController else {
            return
        }
        
        navigationController.popToViewController(navigationController.viewControllers[1], animated: true)
//        self.navigationController?.popToRootViewController(animated: true)
    }
    
}

//
//  ViewController.swift
//  sfNotificationCenter
//
//  Created by agile on 14/12/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblAttributedString: UILabel!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblAttributedString.text = "Hello World"
        
        NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(notification:)), name: NSNotification.Name(rawValue: NSNotification.Name.name), object: nil)
    }
    
    @objc func notificationHandler(notification:Notification) {
        print("Notification Observe1")
        if let userInfo =  notification.userInfo {
            print("Data is \(userInfo)")
        }else{
            print("Data Not Found")
        }
    }
    
    
    @IBAction func btnAttributedStringTest(_ sender: Any) {
        
        var str = lblAttributedString.text!
        
        var attributedString = NSMutableAttributedString(string: str, attributes: nil)
        
        let helloRang = (attributedString.string as NSString).range(of: "Hello")
        attributedString.setAttributes([NSAttributedStringKey.foregroundColor : UIColor.blue], range: helloRang)
        
        lblAttributedString.attributedText = attributedString
    }
}


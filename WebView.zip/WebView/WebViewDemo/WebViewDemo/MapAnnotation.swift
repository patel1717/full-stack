//
//  MapAnnotation.swift
//  WebViewDemo
//
//  Created by agilemac-24 on 12/13/17.
//

import UIKit
import MapKit
class Student :NSObject {
    var strName:String = ""
    
}
class NewAnnotation:NSObject,MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title:String?
    var strPinText:String = ""
    var isDisplayCallOut:Bool = false
    var objStudent:Student?
    init(withCoordination location:CLLocationCoordinate2D) {
        self.coordinate = location
        self.title = "Test"
    }
}

class MapAnnotation: NSObject,MKAnnotation
{
   
    let title: String?
    let locationName: String?
    let discipline: String?
    var coordinate: CLLocationCoordinate2D
    
    init(title: String, locationName: String, discipline: String, coordinate: CLLocationCoordinate2D)
    {
        self.title = title
        self.locationName = locationName
        self.discipline = discipline
        self.coordinate = coordinate
        
        super.init()
        
       
    }
   
    
    
}




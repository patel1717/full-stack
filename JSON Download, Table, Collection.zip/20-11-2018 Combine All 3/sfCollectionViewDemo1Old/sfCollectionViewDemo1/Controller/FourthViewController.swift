//
//  FourthViewController.swift
//  sfCollectionViewDemo1
//
//  Created by agile on 21/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {

    @IBOutlet weak var lblCapitalCollectionView: UILabel!
    @IBOutlet weak var lblRegionCollectionView: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}

//
//  Datamodel.swift
//  sagmetcontrol with tableview
//
//  Created by agilemac-74 on 19/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import Foundation
import UIKit

struct AhmedabadModel {
    let city:String?
    let image:UIImage?
    let title:String?
    
}
struct MumbaiModel {
    let city:String?
    let image:UIImage?
    let title:String?
    
}
struct BangloreModel {
    let city:String?
    let image:UIImage?
    let title:String?
    
}
struct PuneModel {
    let city:String?
    let image:UIImage?
    let title:String?
    
}

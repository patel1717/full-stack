//
//  ViewController.swift
//  CoreData_TEST
//
//  Created by agile-2 on 23/11/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    
    
    @IBOutlet weak var txtNumbe: UITextField!
    @IBOutlet weak var txtToBeDeletedName: UITextField!
    @IBOutlet weak var txtOldName: UITextField!
    @IBOutlet weak var txtNewName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func btnInsertPressed(_ sender: Any) {
 ServiceManager.shared.insertDataToCoreData(name: txtName.text!, number: txtNumbe.text!)
    }
   
    @IBAction func btnFetchPressed(_ sender: Any) {
        ServiceManager.shared.fetchDataFromCoreData()
    }
    
    @IBAction func btnUpdatePressed(_ sender: Any) {
        ServiceManager.shared.updateDataToCoreData(oldName: txtOldName.text!, newName: txtNewName.text!)
    }
    
    @IBAction func btnDeletePressed(_ sender: Any) {
        ServiceManager.shared.deleteDataFromCoreData(nameToBeDeleted: txtToBeDeletedName.text!)
    }
}


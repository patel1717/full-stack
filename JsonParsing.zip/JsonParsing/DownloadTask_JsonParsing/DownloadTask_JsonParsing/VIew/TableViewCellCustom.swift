//
//  TableViewCellCustom.swift
//  DownloadTask_JsonParsing
//
//  Created by agile on 11/11/18.
//  Copyright © 2018 A. All rights reserved.
//

import UIKit
import Foundation

protocol DelegateTableViewCellCustom {
    func downloadTapped(_ cell: TableViewCellCustom)
}

class TableViewCellCustom: UITableViewCell {

     var delegate: DelegateTableViewCellCustom?
    
    @IBOutlet weak var lblTableViewCellCustom: UILabel!
    @IBOutlet weak var downloadButton: UIButton!
    
    @IBAction func btnDownload(_ sender: Any) {
            delegate?.downloadTapped(self)
        
        print("Download Pressed")
    }
    
    
    
    func configure(track: Track, downloaded: Bool, download: Download?) {
        lblTableViewCellCustom.text = track.name
        
        
        // Download controls are Pause/Resume, Cancel buttons, progress info
        var showDownloadControls = false
        // Non-nil Download object means a download is in progress
        if let download = download {
            showDownloadControls = true
            let title = download.isDownloading ? "Download+" : "Download+"
            downloadButton.setTitle(title, for: .normal)
        }
        // If the track is already downloaded, enable cell selection and hide the Download button
        selectionStyle = downloaded ? UITableViewCellSelectionStyle.gray : UITableViewCellSelectionStyle.none
        downloadButton.isHidden = downloaded || showDownloadControls
    }

    

    
}
